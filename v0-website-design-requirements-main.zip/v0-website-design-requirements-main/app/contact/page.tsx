"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Mail, Phone, MapPin, Calendar, Clock, ArrowRight } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ContactPage() {
  const { toast } = useToast()
  const [budget, setBudget] = useState([1000])
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      toast({
        title: "Nachricht gesendet!",
        description: "Wir werden uns so schnell wie möglich bei Ihnen melden.",
      })
      setIsSubmitting(false)
    }, 1500)
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-[#0f0a1e] py-20 md:py-32 overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="blob blob-2 animate-rotate" style={{ animationDirection: "reverse" }}></div>
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 animate-fade-in">Kontakt</h1>
            <p className="text-lg text-white/80 max-w-2xl mx-auto animate-slide-up">
              Haben Sie ein Projekt im Sinn? Kontaktieren Sie uns, um zu besprechen, wie wir Ihre Vision zum Leben
              erwecken können.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Tabs */}
      <section className="py-16 -mt-10 relative z-20">
        <div className="container">
          <Tabs defaultValue="contact" className="w-full max-w-4xl mx-auto">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="contact">Kontaktformular</TabsTrigger>
              <TabsTrigger value="schedule">Termin vereinbaren</TabsTrigger>
            </TabsList>

            <TabsContent value="contact" className="animate-fade-in">
              <Card>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                    <div>
                      <h2 className="text-2xl font-bold mb-6">Kontaktieren Sie uns</h2>
                      <p className="text-muted-foreground mb-8">
                        Füllen Sie das untenstehende Formular aus, um uns über Ihr Projekt zu informieren, und wir
                        werden uns innerhalb von 24 Stunden bei Ihnen melden.
                      </p>

                      <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label htmlFor="name" className="text-sm font-medium">
                              Name <span className="text-red-500">*</span>
                            </label>
                            <Input id="name" placeholder="Ihr Name" required />
                          </div>
                          <div className="space-y-2">
                            <label htmlFor="email" className="text-sm font-medium">
                              E-Mail <span className="text-red-500">*</span>
                            </label>
                            <Input id="email" type="email" placeholder="Ihre E-Mail" required />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label htmlFor="project-type" className="text-sm font-medium">
                            Projekttyp <span className="text-red-500">*</span>
                          </label>
                          <Select required>
                            <SelectTrigger id="project-type">
                              <SelectValue placeholder="Projekttyp auswählen" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="website">Website-Design</SelectItem>
                              <SelectItem value="ecommerce">E-Commerce</SelectItem>
                              <SelectItem value="redesign">Website-Redesign</SelectItem>
                              <SelectItem value="seo">SEO-Optimierung</SelectItem>
                              <SelectItem value="maintenance">Website-Wartung</SelectItem>
                              <SelectItem value="other">Andere</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <label htmlFor="budget" className="text-sm font-medium">
                            Budgetbereich: €{budget[0].toLocaleString()}
                          </label>
                          <Slider
                            id="budget"
                            min={500}
                            max={5000}
                            step={100}
                            value={budget}
                            onValueChange={setBudget}
                          />
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>€500</span>
                            <span>€5.000+</span>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label htmlFor="message" className="text-sm font-medium">
                            Projektdetails <span className="text-red-500">*</span>
                          </label>
                          <Textarea
                            id="message"
                            placeholder="Erzählen Sie uns über Ihr Projekt und Ihre Anforderungen"
                            rows={5}
                            required
                          />
                        </div>

                        <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                          {isSubmitting ? "Wird gesendet..." : "Nachricht senden"}
                        </Button>
                      </form>
                    </div>

                    <div className="space-y-8">
                      <div>
                        <h2 className="text-2xl font-bold mb-6">Kontaktinformationen</h2>
                        <div className="space-y-6">
                          <div className="flex items-start">
                            <Mail className="h-6 w-6 text-primary mr-4 mt-1" />
                            <div>
                              <h3 className="font-semibold mb-1">E-Mail</h3>
                              <a
                                href="mailto:info@webcraftstudio.com"
                                className="text-muted-foreground hover:text-primary"
                              >
                                info@webcraftstudio.com
                              </a>
                            </div>
                          </div>

                          <div className="flex items-start">
                            <Phone className="h-6 w-6 text-primary mr-4 mt-1" />
                            <div>
                              <h3 className="font-semibold mb-1">Telefon</h3>
                              <a href="tel:+4915123456789" className="text-muted-foreground hover:text-primary">
                                +49 151 2345 6789
                              </a>
                            </div>
                          </div>

                          <div className="flex items-start">
                            <MapPin className="h-6 w-6 text-primary mr-4 mt-1" />
                            <div>
                              <h3 className="font-semibold mb-1">Besuchen Sie uns</h3>
                              <p className="text-muted-foreground">
                                Irenenstr. 666
                                <br />
                                40468 Düsseldorf
                                <br />
                                Deutschland
                              </p>
                            </div>
                          </div>

                          <div className="flex items-start">
                            <Clock className="h-6 w-6 text-primary mr-4 mt-1" />
                            <div>
                              <h3 className="font-semibold mb-1">Geschäftszeiten</h3>
                              <p className="text-muted-foreground">
                                Montag - Freitag: 9:00 - 18:00 Uhr
                                <br />
                                Samstag & Sonntag: Geschlossen
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Google Maps Placeholder */}
                      <div className="rounded-lg overflow-hidden border h-64 bg-gray-100 flex items-center justify-center">
                        <div className="text-center p-4">
                          <MapPin className="h-8 w-8 text-primary mx-auto mb-2" />
                          <p className="text-muted-foreground">
                            Google Maps würde hier eingebettet sein
                            <br />
                            <span className="text-sm">Irenenstr. 666, 40468 Düsseldorf</span>
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="schedule" className="animate-fade-in">
              <Card>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                    <div>
                      <h2 className="text-2xl font-bold mb-6">Termin vereinbaren</h2>
                      <p className="text-muted-foreground mb-8">
                        Buchen Sie ein kostenloses Beratungsgespräch mit einem unserer Experten, um Ihr Projekt zu
                        besprechen.
                      </p>

                      {/* Calendly Placeholder */}
                      <div className="rounded-lg overflow-hidden border h-96 bg-gray-100 flex items-center justify-center">
                        <div className="text-center p-4">
                          <Calendar className="h-8 w-8 text-primary mx-auto mb-2" />
                          <p className="text-muted-foreground mb-4">
                            Hier würde ein Calendly-Kalender eingebettet sein
                          </p>
                          <Button asChild className="bg-primary hover:bg-primary/90">
                            <a
                              href="https://calendly.com"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center"
                            >
                              Zum Kalenderbuchungstool <ArrowRight className="ml-2 h-4 w-4" />
                            </a>
                          </Button>
                        </div>
                      </div>

                      <div className="mt-8">
                        <h3 className="text-lg font-semibold mb-4">Warum ein Beratungsgespräch buchen?</h3>
                        <ul className="space-y-2">
                          <li className="flex items-start">
                            <ArrowRight className="h-5 w-5 text-primary mr-2 mt-0.5" />
                            <span>Besprechen Sie Ihre Anforderungen im Detail</span>
                          </li>
                          <li className="flex items-start">
                            <ArrowRight className="h-5 w-5 text-primary mr-2 mt-0.5" />
                            <span>Erhalten Sie eine persönliche Beratung zu Ihrem Projekt</span>
                          </li>
                          <li className="flex items-start">
                            <ArrowRight className="h-5 w-5 text-primary mr-2 mt-0.5" />
                            <span>Lernen Sie unser Team kennen</span>
                          </li>
                          <li className="flex items-start">
                            <ArrowRight className="h-5 w-5 text-primary mr-2 mt-0.5" />
                            <span>Bekommen Sie eine erste Einschätzung zu Kosten und Zeitrahmen</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    <div className="space-y-8">
                      <div>
                        <h2 className="text-2xl font-bold mb-6">Häufig gestellte Fragen</h2>
                        <div className="space-y-6">
                          <div>
                            <h3 className="font-semibold mb-1">Wie lange dauert das Beratungsgespräch?</h3>
                            <p className="text-muted-foreground">
                              Unsere Beratungsgespräche dauern in der Regel 30 Minuten. Bei Bedarf können wir auch
                              längere Gespräche vereinbaren.
                            </p>
                          </div>

                          <div>
                            <h3 className="font-semibold mb-1">Ist das Beratungsgespräch kostenlos?</h3>
                            <p className="text-muted-foreground">
                              Ja, das Erstgespräch ist völlig unverbindlich und kostenlos. Wir möchten Ihnen die
                              Möglichkeit geben, uns kennenzulernen und Ihre Anforderungen zu besprechen.
                            </p>
                          </div>

                          <div>
                            <h3 className="font-semibold mb-1">Wie läuft das Gespräch ab?</h3>
                            <p className="text-muted-foreground">
                              Das Gespräch kann per Telefon, Videoanruf oder persönlich in unserem Büro stattfinden. Wir
                              besprechen Ihre Anforderungen, beantworten Ihre Fragen und geben Ihnen eine erste
                              Einschätzung zu Ihrem Projekt.
                            </p>
                          </div>

                          <div>
                            <h3 className="font-semibold mb-1">Was sollte ich vorbereiten?</h3>
                            <p className="text-muted-foreground">
                              Es ist hilfreich, wenn Sie sich Gedanken zu Ihren Zielen, Ihrem Budget und Ihrem
                              Zeitrahmen machen. Wenn Sie bereits Beispiele von Websites haben, die Ihnen gefallen,
                              können Sie diese gerne teilen.
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-primary/5 rounded-lg p-6 border border-primary/10">
                        <h3 className="font-semibold mb-4 flex items-center">
                          <Calendar className="h-5 w-5 mr-2 text-primary" /> Nächste verfügbare Termine
                        </h3>
                        <ul className="space-y-3">
                          <li className="flex justify-between items-center p-2 hover:bg-primary/10 rounded-md transition-colors">
                            <span>Montag, 20. Mai</span>
                            <span className="text-primary">10:00 - 16:00 Uhr</span>
                          </li>
                          <li className="flex justify-between items-center p-2 hover:bg-primary/10 rounded-md transition-colors">
                            <span>Dienstag, 21. Mai</span>
                            <span className="text-primary">13:00 - 17:00 Uhr</span>
                          </li>
                          <li className="flex justify-between items-center p-2 hover:bg-primary/10 rounded-md transition-colors">
                            <span>Donnerstag, 23. Mai</span>
                            <span className="text-primary">09:00 - 15:00 Uhr</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#0f0a1e] text-white relative overflow-hidden mt-12">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="container text-center max-w-3xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">Bereit, Ihr Projekt zu starten?</h2>
          <p className="text-white/80 text-lg mb-8 animate-slide-up">
            Kontaktieren Sie uns noch heute und lassen Sie uns gemeinsam Ihre Vision verwirklichen.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
            <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
              <Link href="/signup">Konto erstellen</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
              <Link href="/portfolio">Unsere Arbeit ansehen</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
