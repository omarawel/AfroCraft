"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { MessageCircle, X, Send, Bot } from "lucide-react"
import { cn } from "@/lib/utils"

export const ChatbotWidget = function ChatbotWidget() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState([
    {
      role: "bot",
      content: "Hallo! Ich bin dein AfroCraft Assistent. Wie kann ich dir heute helfen?",
    },
  ])
  const [input, setInput] = useState("")
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Show chatbot button after 3 seconds
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 3000)

    return () => clearTimeout(timer)
  }, [])

  const toggleChat = () => {
    setIsOpen(!isOpen)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    // Add user message
    setMessages((prev) => [...prev, { role: "user", content: input }])

    // Simulate bot response
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          role: "bot",
          content:
            "Danke für deine Nachricht! Ich kann dir bei der Erstellung deiner Website helfen. Möchtest du mehr über unsere Templates oder Preise erfahren?",
        },
      ])
    }, 1000)

    setInput("")
  }

  const predefinedQuestions = [
    "Wie funktioniert AfroCraft?",
    "Was kostet eine Website?",
    "Wie lange dauert die Erstellung einer Website?",
  ]

  const handlePredefinedQuestion = (question: string) => {
    // Add user message
    setMessages((prev) => [...prev, { role: "user", content: question }])

    // Simulate bot response based on question
    setTimeout(() => {
      let response = ""

      if (question.includes("funktioniert")) {
        response =
          "AfroCraft ermöglicht es dir, professionelle Websites zu erstellen. Du beschreibst deine Idee, wir generieren Designs, und du kannst sie anpassen und veröffentlichen. Alles ohne Programmierkenntnisse!"
      } else if (question.includes("kostet")) {
        response =
          "Wir bieten verschiedene Preispläne an: Basic (€600), Pro (€1.100) und Premium (€2.000). Du kannst auch eine individuelle Demo anfragen!"
      } else if (question.includes("lange dauert")) {
        response =
          "Mit AfroCraft kannst du eine professionelle Website in wenigen Tagen erstellen. Einfache Websites können sogar in wenigen Stunden fertig sein!"
      }

      setMessages((prev) => [
        ...prev,
        {
          role: "bot",
          content: response,
        },
      ])
    }, 1000)
  }

  return (
    <>
      <Button
        onClick={toggleChat}
        className={cn(
          "fixed bottom-4 right-4 rounded-full w-12 h-12 p-0 shadow-lg z-50 transition-all duration-300",
          isOpen ? "bg-gray-200 text-gray-800 hover:bg-gray-300" : "bg-primary hover:bg-primary/90 text-white",
          !isVisible && "translate-y-20 opacity-0",
        )}
        aria-label="Chat with us"
      >
        {isOpen ? <X className="h-5 w-5" /> : <MessageCircle className="h-5 w-5" />}
      </Button>

      <div
        className={cn(
          "fixed bottom-20 right-4 w-80 md:w-96 z-50 transition-all duration-300 ease-in-out transform",
          isOpen ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0 pointer-events-none",
        )}
      >
        <Card className="shadow-xl border-primary/10">
          <CardHeader className="bg-primary text-white py-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <Bot className="h-5 w-5" />
              AfroCraft Assistent
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 h-80 overflow-y-auto">
            <div className="space-y-4">
              {messages.map((message, index) => (
                <div key={index} className={cn("flex", message.role === "user" ? "justify-end" : "justify-start")}>
                  <div
                    className={cn(
                      "max-w-[80%] rounded-lg p-3",
                      message.role === "user" ? "bg-primary text-white" : "bg-gray-100 dark:bg-gray-800",
                    )}
                  >
                    <p className="text-sm">{message.content}</p>
                  </div>
                </div>
              ))}
            </div>

            {messages.length === 1 && (
              <div className="mt-4 space-y-2">
                <p className="text-xs text-gray-500 dark:text-gray-400">Häufig gestellte Fragen:</p>
                {predefinedQuestions.map((question, index) => (
                  <button
                    key={index}
                    className="text-sm text-left w-full p-2 rounded-md bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 transition-colors"
                    onClick={() => handlePredefinedQuestion(question)}
                  >
                    {question}
                  </button>
                ))}
              </div>
            )}
          </CardContent>
          <CardFooter className="p-3 border-t">
            <form onSubmit={handleSubmit} className="flex w-full gap-2">
              <Input
                placeholder="Schreibe deine Nachricht..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" size="icon" className="bg-primary hover:bg-primary/90 text-white">
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardFooter>
        </Card>
      </div>
    </>
  )
}

// Also export as default for backward compatibility
export default ChatbotWidget
