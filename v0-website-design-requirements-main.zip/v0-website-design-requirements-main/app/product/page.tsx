import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle2, Zap, Code, Layout, Palette, CheckCircle } from "lucide-react"

export default function Page() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-[#0f0a1e] py-20 md:py-32 overflow-hidden">
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight text-white animate-fade-in">
              <span className="block">Professionelles Webdesign</span>
              <span className="block">
                <span className="text-primary">ohne Kompromisse</span>
              </span>
            </h1>
            <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto animate-slide-up">
              Unsere Plattform bietet leistungsstarke Tools und Funktionen, um beeindruckende Websites zu erstellen, die
              Ihre Marke perfekt repräsentieren.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
              <Button asChild size="lg" className="bg-[#E5007D] text-[#FFFFFF] hover:bg-[#E5007D]/90">
                <Link href="/signup">Kostenlos starten</Link>
                </Button>
                <Button asChild size="lg" className="bg-[#E5007D] text-[#FFFFFF] hover:bg-[#E5007D]/90">
                  <Link href="/contact">Demo anfragen</Link>
                  </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Product Features */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Alles was Sie für Ihren Erfolg brauchen</h2>
            <p className="text-muted-foreground text-lg">
              WebCraft Studio bietet eine umfassende Lösung für die Erstellung professioneller Websites.
            </p>
          </div>

          <Tabs defaultValue="design" className="w-full max-w-4xl mx-auto">
            <TabsList className="grid w-full grid-cols-3 mb-12">
              <TabsTrigger value="design">Design</TabsTrigger>
              <TabsTrigger value="development">Entwicklung</TabsTrigger>
              <TabsTrigger value="tools">Tools</TabsTrigger>
            </TabsList>

            <TabsContent value="design" className="animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                  <h3 className="text-2xl font-bold">Professionelles Design ohne Vorkenntnisse</h3>
                  <p className="text-muted-foreground">
                    Erstellen Sie beeindruckende Websites mit unseren intuitiven Design-Tools. Wählen Sie aus Hunderten
                    von Vorlagen und passen Sie sie an Ihre Marke an.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Drag-and-Drop-Editor für einfache Anpassungen</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Responsive Design für alle Geräte</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Umfangreiche Bibliothek mit Designelementen</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Anpassbare Farbschemata und Typografie</span>
                    </li>
                  </ul>
                  <Button asChild className="bg-primary hover:bg-primary/90">
                    <Link href="/templates">Templates entdecken</Link>
                  </Button>
                </div>
                <div className="rounded-lg overflow-hidden shadow-xl">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    alt="Design Interface"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="development" className="animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className="rounded-lg overflow-hidden shadow-xl order-2 md:order-1">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    alt="Development Interface"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
                <div className="space-y-6 order-1 md:order-2">
                  <h3 className="text-2xl font-bold">Leistungsstarke Entwicklungstools</h3>
                  <p className="text-muted-foreground">
                    Nutzen Sie unsere fortschrittlichen Entwicklungstools, um Ihre Website mit benutzerdefinierten
                    Funktionen zu erweitern.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Sauberer, optimierter Code</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Integrierte Entwicklungsumgebung</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>API-Integrationen für erweiterte Funktionalität</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Versionskontrolle und Backup-Funktionen</span>
                    </li>
                  </ul>
                  <Button asChild className="bg-primary hover:bg-primary/90">
                    <Link href="/solutions">Lösungen erkunden</Link>
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="tools" className="animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                  <h3 className="text-2xl font-bold">Umfassende Toolbox für Ihren Erfolg</h3>
                  <p className="text-muted-foreground">
                    Nutzen Sie unsere vielseitigen Tools, um Ihre Website zu optimieren und Ihren Online-Erfolg zu
                    steigern.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>SEO-Optimierungstools</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Leistungsanalyse und Berichte</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Marketing-Integrationen</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>E-Commerce-Funktionen</span>
                    </li>
                  </ul>
                  <Button asChild className="bg-primary hover:bg-primary/90">
                    <Link href="/pricing">Preise ansehen</Link>
                  </Button>
                </div>
                <div className="rounded-lg overflow-hidden shadow-xl">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    alt="Tools Interface"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Funktionen im Überblick</h2>
            <p className="text-muted-foreground text-lg">
              Entdecken Sie die vielfältigen Funktionen, die WebCraft Studio zu bieten hat.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-white border rounded-lg p-6 hover:shadow-md transition-all">
              <CardContent className="p-0">
                <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <Zap className="text-primary h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Schnelle Ladezeiten</h3>
                <p className="text-muted-foreground mb-4">
                  Optimierte Websites für schnelle Ladezeiten und ein besseres Nutzererlebnis.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white border rounded-lg p-6 hover:shadow-md transition-all">
              <CardContent className="p-0">
                <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <Code className="text-primary h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Sauberer Code</h3>
                <p className="text-muted-foreground mb-4">
                  Professioneller, wartbarer Code, der den neuesten Standards entspricht.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white border rounded-lg p-6 hover:shadow-md transition-all">
              <CardContent className="p-0">
                <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <Layout className="text-primary h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Responsive Design</h3>
                <p className="text-muted-foreground mb-4">
                  Websites, die auf allen Geräten perfekt aussehen und funktionieren.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white border rounded-lg p-6 hover:shadow-md transition-all">
              <CardContent className="p-0">
                <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <Palette className="text-primary h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Anpassbare Designs</h3>
                <p className="text-muted-foreground mb-4">Passen Sie jedes Element an Ihre Marke und Ihren Stil an.</p>
              </CardContent>
            </Card>

            <Card className="bg-white border rounded-lg p-6 hover:shadow-md transition-all">
              <CardContent className="p-0">
                <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <CheckCircle className="text-primary h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">SEO-Optimierung</h3>
                <p className="text-muted-foreground mb-4">
                  Integrierte Tools zur Verbesserung Ihrer Sichtbarkeit in Suchmaschinen.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white border rounded-lg p-6 hover:shadow-md transition-all">
              <CardContent className="p-0">
                <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <CheckCircle2 className="text-primary h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Einfache Verwaltung</h3>
                <p className="text-muted-foreground mb-4">
                  Benutzerfreundliches Content-Management-System für einfache Updates.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#0f0a1e] text-white relative overflow-hidden">
        <div className="container text-center max-w-3xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Bereit, Ihre Website zu erstellen?</h2>
          <p className="text-white/80 text-lg mb-8">
            Starten Sie noch heute mit WebCraft Studio und bringen Sie Ihre Online-Präsenz auf ein neues Level.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-[#E5007D] text-[#FFFFFF] hover:bg-[#E5007D]/90">
              <Link href="/signup">Kostenlos starten</Link>
              </Button>
              <Button asChild size="lg" className="bg-[#E5007D] text-[#FFFFFF] hover:bg-[#E5007D]/90">
                <Link href="/contact">Demo anfragen</Link>
                </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
