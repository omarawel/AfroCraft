"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Eye, EyeOff } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function LoginPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [userType, setUserType] = useState("customer")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Validate form
    if (!email || !password) {
      toast({
        title: "Error",
        description: "Bitte geben Sie sowohl E-Mail als auch Passwort ein.",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    // Submit form - in a real app, this would call an API
    setTimeout(() => {
      toast({
        title: "Login erfolgreich!",
        description: "Sie sind jetzt eingeloggt.",
      })

      // Redirect to appropriate dashboard based on user type
      if (userType === "admin") {
        router.push("/admin")
      } else {
        router.push("/dashboard")
      }
      setIsLoading(false)
    }, 1500)
  }

  return (
    <div className="container max-w-md mx-auto py-12">
      <Card className="w-full">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">Login</CardTitle>
          <CardDescription className="text-center">
            Geben Sie Ihre E-Mail und Ihr Passwort ein, um auf Ihr Konto zuzugreifen
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="customer" onValueChange={setUserType} className="mb-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="customer">Kunde</TabsTrigger>
              <TabsTrigger value="admin">Administrator</TabsTrigger>
            </TabsList>
            <TabsContent value="customer">
              <p className="text-sm text-muted-foreground mt-2">
                Melden Sie sich als Kunde an, um auf Ihre Projekte und Dokumente zuzugreifen.
              </p>
            </TabsContent>
            <TabsContent value="admin">
              <p className="text-sm text-muted-foreground mt-2">
                Administratorzugang nur für autorisierte Mitarbeiter von WebCraft Studio.
              </p>
            </TabsContent>
          </Tabs>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">E-Mail</Label>
              <Input
                id="email"
                type="email"
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="password">Passwort</Label>
                <Link href="/forgot-password" className="text-sm text-primary hover:underline">
                  Passwort vergessen?
                </Link>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="remember"
                checked={rememberMe}
                onCheckedChange={(checked) => setRememberMe(checked as boolean)}
              />
              <label
                htmlFor="remember"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Angemeldet bleiben
              </label>
            </div>

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? "Anmeldung läuft..." : "Anmelden"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-center text-sm">
            <span>Noch kein Konto? </span>
            <Link href="/signup" className="text-primary hover:underline">
              Registrieren
            </Link>
          </div>
          <div className="text-center text-xs text-muted-foreground">
            Durch die Anmeldung stimmen Sie unseren{" "}
            <Link href="/terms" className="text-primary hover:underline">
              Nutzungsbedingungen
            </Link>{" "}
            und{" "}
            <Link href="/privacy" className="text-primary hover:underline">
              Datenschutzrichtlinien
            </Link>{" "}
            zu.
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
