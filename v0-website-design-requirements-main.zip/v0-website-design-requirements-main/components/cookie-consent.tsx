"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

export function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const consent = localStorage.getItem("cookie-consent")
    if (!consent) {
      setIsVisible(true)
    }
  }, [])

  const acceptAll = () => {
    localStorage.setItem("cookie-consent", "all")
    setIsVisible(false)
  }

  const acceptEssential = () => {
    localStorage.setItem("cookie-consent", "essential")
    setIsVisible(false)
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4 bg-background border-t shadow-lg dark:border-gray-700">
      <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold mb-2">Wir verwenden Cookies</h3>
          <p className="text-sm text-muted-foreground">
            Wir verwenden Cookies, um Ihnen die bestmögliche Erfahrung auf unserer Website zu bieten. Durch die Nutzung
            unserer Website stimmen Sie der Verwendung von Cookies gemäß unserer
            <a href="/privacy" className="text-primary hover:underline ml-1">
              Datenschutzrichtlinie
            </a>{" "}
            zu.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={acceptEssential}>
            Nur Essenzielle
          </Button>
          <Button onClick={acceptAll}>Alle akzeptieren</Button>
          <Button variant="ghost" size="icon" onClick={acceptEssential} className="rounded-full">
            <X className="h-4 w-4" />
            <span className="sr-only">Schließen</span>
          </Button>
        </div>
      </div>
    </div>
  )
}
