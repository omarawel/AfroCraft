"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Eye, EyeOff } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function SignupPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [userType, setUserType] = useState("customer")
  const [formData, setFormData] = useState({
    email: "",
    firstName: "",
    lastName: "",
    password: "",
    website: "",
    phone: "",
    companyName: "",
    companySize: "",
    country: "",
    termsAccepted: false,
    marketingOptIn: false,
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Validate form
    if (
      !formData.email ||
      !formData.firstName ||
      !formData.lastName ||
      !formData.password ||
      !formData.companyName ||
      !formData.country
    ) {
      toast({
        title: "Fehler",
        description: "Bitte füllen Sie alle erforderlichen Felder aus.",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    if (!formData.termsAccepted) {
      toast({
        title: "Fehler",
        description: "Sie müssen die Nutzungsbedingungen akzeptieren, um ein Konto zu erstellen.",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    // Submit form - in a real app, this would call an API
    setTimeout(() => {
      toast({
        title: "Konto erstellt!",
        description: "Ihr Konto wurde erfolgreich erstellt.",
      })

      // Redirect to appropriate dashboard based on user type
      if (userType === "admin") {
        router.push("/admin")
      } else {
        router.push("/dashboard")
      }
      setIsLoading(false)
    }, 1500)
  }

  return (
    <div className="container max-w-md mx-auto py-12">
      <Card className="w-full">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">Konto erstellen</CardTitle>
          <CardDescription className="text-center">Geben Sie Ihre Daten ein, um ein Konto zu erstellen</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="customer" onValueChange={setUserType} className="mb-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="customer">Kunde</TabsTrigger>
              <TabsTrigger value="admin">Administrator</TabsTrigger>
            </TabsList>
            <TabsContent value="customer">
              <p className="text-sm text-muted-foreground mt-2">
                Erstellen Sie ein Kundenkonto, um Ihre Projekte zu verwalten und mit unserem Team zu kommunizieren.
              </p>
            </TabsContent>
            <TabsContent value="admin">
              <p className="text-sm text-muted-foreground mt-2">
                Administratorkonten sind nur für autorisierte Mitarbeiter von WebCraft Studio. Benötigt Genehmigung.
              </p>
            </TabsContent>
          </Tabs>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email">
                E-Mail<span className="text-red-500">*</span>
              </Label>
              <p className="text-xs text-muted-foreground">Dies wird als Ihr Benutzername verwendet</p>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="name@example.com"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">
                  Vorname<span className="text-red-500">*</span>
                </Label>
                <Input
                  id="firstName"
                  name="firstName"
                  placeholder="Max"
                  value={formData.firstName}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">
                  Nachname<span className="text-red-500">*</span>
                </Label>
                <Input
                  id="lastName"
                  name="lastName"
                  placeholder="Mustermann"
                  value={formData.lastName}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">
                Passwort<span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  name="website"
                  placeholder="www.example.com"
                  value={formData.website}
                  onChange={handleChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Telefon</Label>
                <Input
                  id="phone"
                  name="phone"
                  placeholder="+49 123 456789"
                  value={formData.phone}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="companyName">
                  Firmenname<span className="text-red-500">*</span>
                </Label>
                <Input
                  id="companyName"
                  name="companyName"
                  placeholder="Acme GmbH"
                  value={formData.companyName}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="companySize">Unternehmensgröße</Label>
                <Select onValueChange={(value) => handleSelectChange("companySize", value)}>
                  <SelectTrigger id="companySize">
                    <SelectValue placeholder="Größe wählen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1-10">1-10 Mitarbeiter</SelectItem>
                    <SelectItem value="11-50">11-50 Mitarbeiter</SelectItem>
                    <SelectItem value="51-200">51-200 Mitarbeiter</SelectItem>
                    <SelectItem value="201-500">201-500 Mitarbeiter</SelectItem>
                    <SelectItem value="501+">501+ Mitarbeiter</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="country">
                Land<span className="text-red-500">*</span>
              </Label>
              <Select onValueChange={(value) => handleSelectChange("country", value)} required>
                <SelectTrigger id="country">
                  <SelectValue placeholder="Land auswählen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="germany">Deutschland</SelectItem>
                  <SelectItem value="austria">Österreich</SelectItem>
                  <SelectItem value="switzerland">Schweiz</SelectItem>
                  <SelectItem value="france">Frankreich</SelectItem>
                  <SelectItem value="uk">Großbritannien</SelectItem>
                  <SelectItem value="other">Anderes Land</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-4">
              <div className="flex items-start space-x-2">
                <Checkbox
                  id="terms"
                  checked={formData.termsAccepted}
                  onCheckedChange={(checked) => handleCheckboxChange("termsAccepted", checked as boolean)}
                />
                <div className="grid gap-1.5 leading-none">
                  <label
                    htmlFor="terms"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Durch Klicken auf "Konto erstellen" stimmen Sie den{" "}
                    <Link href="/terms" className="text-primary hover:underline">
                      Nutzungsbedingungen
                    </Link>{" "}
                    zu und bestätigen, dass Sie die{" "}
                    <Link href="/privacy" className="text-primary hover:underline">
                      Datenschutzrichtlinie
                    </Link>{" "}
                    von WebCraft Studio gelesen haben
                    <span className="text-red-500">*</span>
                  </label>
                </div>
              </div>

              <div className="flex items-start space-x-2">
                <Checkbox
                  id="marketing"
                  checked={formData.marketingOptIn}
                  onCheckedChange={(checked) => handleCheckboxChange("marketingOptIn", checked as boolean)}
                />
                <div className="grid gap-1.5 leading-none">
                  <label
                    htmlFor="marketing"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Bitte senden Sie mir Informationen über WebCraft Studio Marketing, News und Updates. Ich verstehe,
                    dass ich mich jederzeit abmelden kann.
                  </label>
                </div>
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? "Konto wird erstellt..." : "Konto erstellen"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex justify-center">
          <p className="text-sm text-center">
            Bereits ein Konto?{" "}
            <Link href="/login" className="text-primary hover:underline">
              Anmelden
            </Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  )
}
