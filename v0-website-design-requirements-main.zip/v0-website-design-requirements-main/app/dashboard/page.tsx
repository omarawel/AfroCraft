"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  FileText,
  MessageSquare,
  Calendar,
  Clock,
  ArrowRight,
  Download,
  Upload,
  CheckCircle2,
  AlertCircle,
} from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ClientDashboardPage() {
  const [activeTab, setActiveTab] = useState("projects")

  return (
    <div className="container py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Kunden-Dashboard</h1>
          <p className="text-muted-foreground">
            Willkommen zurück, Max Mustermann. Hier ist der Status Ihrer Projekte.
          </p>
        </div>
        <Button asChild className="bg-primary hover:bg-primary/90">
          <Link href="/contact">
            <MessageSquare className="h-4 w-4 mr-2" />
            Support kontaktieren
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Aktive Projekte</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
            <p className="text-xs text-muted-foreground">In Bearbeitung</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Abgeschlossene Projekte</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">Erfolgreich abgeschlossen</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Support-Tickets</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">1</span> offen
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Nächster Termin</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">15.05</div>
            <p className="text-xs text-muted-foreground">Projekt-Review um 14:00 Uhr</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="projects" value={activeTab} onValueChange={setActiveTab} className="space-y-8">
        <TabsList className="grid grid-cols-3 w-full max-w-md">
          <TabsTrigger value="projects">Projekte</TabsTrigger>
          <TabsTrigger value="files">Dateien</TabsTrigger>
          <TabsTrigger value="messages">Nachrichten</TabsTrigger>
        </TabsList>

        <TabsContent value="projects" className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Ihre Projekte</CardTitle>
              <CardDescription>Übersicht und Status Ihrer aktuellen und abgeschlossenen Projekte</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {projects.map((project, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 gap-2">
                      <div>
                        <h3 className="font-semibold text-lg">{project.name}</h3>
                        <p className="text-sm text-muted-foreground">{project.description}</p>
                      </div>
                      <div
                        className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                          project.status === "In Bearbeitung"
                            ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                            : project.status === "Abgeschlossen"
                              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                              : "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
                        }`}
                      >
                        {project.status}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Fortschritt</span>
                        <span>{project.progress}%</span>
                      </div>
                      <Progress value={project.progress} className="h-2" />
                    </div>

                    <div className="mt-4 flex flex-wrap gap-4">
                      <div className="flex items-center text-sm">
                        <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                        <span>Start: {project.startDate}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                        <span>Ende: {project.endDate}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
                        <span>Letzte Aktualisierung: {project.lastUpdate}</span>
                      </div>
                    </div>

                    <div className="mt-4 flex justify-end">
                      <Button asChild variant="outline" size="sm">
                        <Link href={`/dashboard/projects/${project.id}`}>
                          Details <ArrowRight className="h-4 w-4 ml-1" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="files" className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Ihre Dateien</CardTitle>
              <CardDescription>Hochgeladene und geteilte Dateien für Ihre Projekte</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {files.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center mr-3">
                        <FileText className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{file.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {file.size} • {file.uploadDate} • {file.project}
                        </p>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                ))}

                <div className="mt-6 flex justify-center">
                  <Button variant="outline" className="w-full max-w-xs">
                    <Upload className="h-4 w-4 mr-2" />
                    Neue Datei hochladen
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="messages" className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Ihre Nachrichten</CardTitle>
              <CardDescription>Kommunikation mit unserem Team</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {messages.map((message, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-muted flex-shrink-0">
                        <Image
                          src={message.avatar || "/placeholder.svg?height=40&width=40"}
                          alt={message.from}
                          width={40}
                          height={40}
                          className="object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1">
                          <div className="font-medium">{message.from}</div>
                          <div className="text-xs text-muted-foreground">{message.date}</div>
                        </div>
                        <div className="text-sm">{message.subject}</div>
                        <p className="text-sm text-muted-foreground mt-1">{message.preview}</p>
                        <div className="mt-2 flex justify-end">
                          <Button variant="ghost" size="sm">
                            Antworten
                          </Button>
                          <Button variant="ghost" size="sm">
                            Vollständig anzeigen
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                <div className="mt-6 flex justify-center">
                  <Button variant="outline" className="w-full max-w-xs">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Neue Nachricht senden
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-8">
        <Card>
          <CardHeader>
            <CardTitle>Projektmeilensteine</CardTitle>
            <CardDescription>Wichtige Termine und Meilensteine für Ihre Projekte</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className="flex">
                  <div className="relative mr-4">
                    <div
                      className={`flex h-10 w-10 items-center justify-center rounded-full ${
                        milestone.completed
                          ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                          : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                      }`}
                    >
                      {milestone.completed ? <CheckCircle2 className="h-5 w-5" /> : <AlertCircle className="h-5 w-5" />}
                    </div>
                    {index !== milestones.length - 1 && (
                      <div className="absolute bottom-0 left-1/2 top-10 w-px -translate-x-1/2 bg-border"></div>
                    )}
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <p className="text-sm font-medium">{milestone.title}</p>
                    <p className="text-sm text-muted-foreground">{milestone.description}</p>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span>{milestone.date}</span>
                      {milestone.project && (
                        <>
                          <span className="mx-1">•</span>
                          <span>{milestone.project}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

const projects = [
  {
    id: "1",
    name: "Unternehmenswebsite Redesign",
    description: "Komplettes Redesign der Unternehmenswebsite mit modernem, responsivem Design",
    status: "In Bearbeitung",
    progress: 65,
    startDate: "01.04.2025",
    endDate: "30.05.2025",
    lastUpdate: "12.05.2025",
  },
  {
    id: "2",
    name: "E-Commerce Integration",
    description: "Integration eines Online-Shops in die bestehende Website",
    status: "In Bearbeitung",
    progress: 30,
    startDate: "01.05.2025",
    endDate: "15.06.2025",
    lastUpdate: "10.05.2025",
  },
  {
    id: "3",
    name: "SEO-Optimierung",
    description: "Suchmaschinenoptimierung für bessere Rankings",
    status: "Abgeschlossen",
    progress: 100,
    startDate: "15.03.2025",
    endDate: "15.04.2025",
    lastUpdate: "15.04.2025",
  },
  {
    id: "4",
    name: "Content-Erstellung",
    description: "Erstellung von Inhalten für die neue Website",
    status: "Abgeschlossen",
    progress: 100,
    startDate: "01.03.2025",
    endDate: "31.03.2025",
    lastUpdate: "31.03.2025",
  },
  {
    id: "5",
    name: "Social Media Integration",
    description: "Integration von Social Media Feeds und Sharing-Funktionen",
    status: "Abgeschlossen",
    progress: 100,
    startDate: "15.02.2025",
    endDate: "28.02.2025",
    lastUpdate: "28.02.2025",
  },
]

const files = [
  {
    name: "Website_Mockups_v2.pdf",
    size: "4.2 MB",
    uploadDate: "12.05.2025",
    project: "Unternehmenswebsite Redesign",
  },
  {
    name: "Logo_Varianten.zip",
    size: "8.7 MB",
    uploadDate: "05.05.2025",
    project: "Unternehmenswebsite Redesign",
  },
  {
    name: "Produktbilder.zip",
    size: "15.3 MB",
    uploadDate: "03.05.2025",
    project: "E-Commerce Integration",
  },
  {
    name: "SEO_Bericht_April.pdf",
    size: "2.1 MB",
    uploadDate: "15.04.2025",
    project: "SEO-Optimierung",
  },
  {
    name: "Content_Plan_Q2.xlsx",
    size: "1.8 MB",
    uploadDate: "31.03.2025",
    project: "Content-Erstellung",
  },
]

const messages = [
  {
    from: "Sarah Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    subject: "Update zu Ihrem Website-Redesign",
    preview: "Hallo Max, ich wollte Ihnen ein Update zu den neuesten Änderungen am Design geben...",
    date: "Heute, 10:23",
  },
  {
    from: "David Wilson",
    avatar: "/placeholder.svg?height=40&width=40",
    subject: "E-Commerce Integration - Nächste Schritte",
    preview: "Guten Tag, für die Integration des Zahlungssystems benötigen wir noch folgende Informationen...",
    date: "Gestern, 15:47",
  },
  {
    from: "Julia Weber",
    avatar: "/placeholder.svg?height=40&width=40",
    subject: "SEO-Bericht April 2025",
    preview: "Sehr geehrter Herr Mustermann, anbei finden Sie den SEO-Bericht für April. Die Rankings haben sich...",
    date: "15.04.2025",
  },
]

const milestones = [
  {
    title: "Design-Abnahme",
    description: "Finale Abnahme der Website-Designs",
    date: "15.05.2025",
    project: "Unternehmenswebsite Redesign",
    completed: false,
  },
  {
    title: "Content-Migration",
    description: "Übertragung aller Inhalte auf die neue Website",
    date: "20.05.2025",
    project: "Unternehmenswebsite Redesign",
    completed: false,
  },
  {
    title: "Produktkatalog-Setup",
    description: "Einrichtung des Produktkatalogs für den Online-Shop",
    date: "25.05.2025",
    project: "E-Commerce Integration",
    completed: false,
  },
  {
    title: "SEO-Optimierung",
    description: "Abschluss der SEO-Optimierungsmaßnahmen",
    date: "15.04.2025",
    project: "SEO-Optimierung",
    completed: true,
  },
  {
    title: "Content-Erstellung",
    description: "Fertigstellung aller Website-Inhalte",
    date: "31.03.2025",
    project: "Content-Erstellung",
    completed: true,
  },
]
