import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { formatDate } from "@/lib/utils"
import { ArrowRight, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"

export default function BlogPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-[#0f0a1e] py-20 md:py-32 overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="blob blob-2 animate-rotate" style={{ animationDirection: "reverse" }}></div>
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 animate-fade-in">Blog</h1>
            <p className="text-lg text-white/80 max-w-2xl mx-auto animate-slide-up">
              Insights, Tutorials und News über Webdesign, Entwicklung und digitale Trends.
            </p>
            <div className="relative max-w-xl mx-auto animate-slide-up">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Suchen Sie nach Artikeln..."
                className="pl-10 h-12 bg-white/10 backdrop-blur-sm text-white border-0 placeholder:text-white/50 focus-visible:ring-primary"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Blog Filter - Mobile Carousel */}
      <div className="md:hidden py-8 -mt-10 relative z-20">
        <div className="container">
          <Carousel className="w-full">
            <CarouselContent>
              <CarouselItem className="basis-auto">
                <Button variant="ghost" className="w-full">
                  Alle Beiträge
                </Button>
              </CarouselItem>
              <CarouselItem className="basis-auto">
                <Button variant="ghost" className="w-full">
                  Design
                </Button>
              </CarouselItem>
              <CarouselItem className="basis-auto">
                <Button variant="ghost" className="w-full">
                  Entwicklung
                </Button>
              </CarouselItem>
              <CarouselItem className="basis-auto">
                <Button variant="ghost" className="w-full">
                  SEO
                </Button>
              </CarouselItem>
              <CarouselItem className="basis-auto">
                <Button variant="ghost" className="w-full">
                  Business
                </Button>
              </CarouselItem>
            </CarouselContent>
            <CarouselPrevious className="left-0" />
            <CarouselNext className="right-0" />
          </Carousel>
        </div>
      </div>

      {/* Blog Filter - Desktop */}
      <section className="py-16 -mt-10 relative z-20">
        <div className="container">
          <Tabs defaultValue="all" className="w-full max-w-6xl mx-auto">
            <TabsList className="hidden md:grid w-full grid-cols-5 mb-12">
              <TabsTrigger value="all" className="text-center px-1">
                Alle Beiträge
              </TabsTrigger>
              <TabsTrigger value="design" className="text-center px-1">
                Design
              </TabsTrigger>
              <TabsTrigger value="development" className="text-center px-1">
                Entwicklung
              </TabsTrigger>
              <TabsTrigger value="seo" className="text-center px-1">
                SEO
              </TabsTrigger>
              <TabsTrigger value="business" className="text-center px-1">
                Business
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {blogPosts.map((post, index) => (
                  <BlogCard key={index} post={post} index={index} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="design" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {blogPosts
                  .filter((post) => post.category === "Design")
                  .map((post, index) => (
                    <BlogCard key={index} post={post} index={index} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="development" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {blogPosts
                  .filter((post) => post.category === "Development")
                  .map((post, index) => (
                    <BlogCard key={index} post={post} index={index} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="seo" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {blogPosts
                  .filter((post) => post.category === "SEO")
                  .map((post, index) => (
                    <BlogCard key={index} post={post} index={index} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="business" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {blogPosts
                  .filter((post) => post.category === "Business")
                  .map((post, index) => (
                    <BlogCard key={index} post={post} index={index} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex justify-center mt-12">
            <Button variant="outline" className="mr-2">
              Vorherige
            </Button>
            <Button variant="outline">Nächste</Button>
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Beliebte Artikel</h2>
            <p className="text-muted-foreground text-lg">
              Unsere meistgelesenen Beiträge mit wertvollen Tipps und Einblicken.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {blogPosts
              .filter((post) => post.featured)
              .slice(0, 2)
              .map((post, index) => (
                <Card key={index} className="overflow-hidden hover:shadow-lg transition-all">
                  <div className="relative h-64 overflow-hidden">
                    <Image
                      src={post.image || "/placeholder.svg?height=300&width=600"}
                      alt={post.title}
                      fill
                      className="object-cover"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="bg-primary text-white text-xs px-2 py-1 rounded-full">Featured</span>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">{post.category}</span>
                      <span className="text-xs text-muted-foreground">{formatDate(post.date)}</span>
                    </div>
                    <h3 className="text-xl font-bold mb-2">{post.title}</h3>
                    <p className="text-muted-foreground mb-4 line-clamp-3">{post.excerpt}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-muted mr-2">
                          <Image
                            src={post.author.avatar || "/placeholder.svg?height=32&width=32"}
                            alt={post.author.name}
                            width={32}
                            height={32}
                            className="object-cover"
                          />
                        </div>
                        <span className="text-sm">{post.author.name}</span>
                      </div>
                      <Link
                        href={`/blog/${post.slug}`}
                        className="text-primary font-medium flex items-center hover:underline"
                      >
                        Weiterlesen <ArrowRight className="h-4 w-4 ml-1" />
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 bg-[#0f0a1e] text-white relative overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="container text-center max-w-3xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">Abonnieren Sie unseren Newsletter</h2>
          <p className="text-white/80 text-lg mb-8 animate-slide-up">
            Erhalten Sie die neuesten Artikel, Tutorials und Updates direkt in Ihren Posteingang.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up max-w-md mx-auto">
            <Input
              type="email"
              placeholder="Ihre E-Mail-Adresse"
              className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
            />
            <Button className="bg-white text-primary hover:bg-white/90">Abonnieren</Button>
          </div>
          <p className="text-white/60 text-xs mt-4 animate-slide-up">
            Wir respektieren Ihre Privatsphäre. Sie können sich jederzeit abmelden.
          </p>
        </div>
      </section>
    </div>
  )
}

interface BlogPost {
  title: string
  slug: string
  category: string
  date: string
  image: string
  excerpt: string
  featured: boolean
  author: {
    name: string
    avatar: string
  }
}

function BlogCard({ post, index }: { post: BlogPost; index: number }) {
  return (
    <Card
      className="overflow-hidden hover:shadow-lg transition-all animate-scale"
      style={{ animationDelay: `${index * 0.1}s` }}
    >
      <div className="relative h-48 overflow-hidden">
        <Image
          src={post.image || "/placeholder.svg?height=200&width=400"}
          alt={post.title}
          fill
          className="object-cover"
        />
      </div>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">{post.category}</span>
          <span className="text-xs text-muted-foreground">{formatDate(post.date)}</span>
        </div>
        <h3 className="text-xl font-bold mb-2">{post.title}</h3>
        <p className="text-muted-foreground mb-4 line-clamp-3">{post.excerpt}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full overflow-hidden bg-muted mr-2">
              <Image
                src={post.author.avatar || "/placeholder.svg?height=32&width=32"}
                alt={post.author.name}
                width={32}
                height={32}
                className="object-cover"
              />
            </div>
            <span className="text-sm">{post.author.name}</span>
          </div>
          <Link href={`/blog/${post.slug}`} className="text-primary font-medium flex items-center hover:underline">
            Weiterlesen <ArrowRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}

// Sample blog posts data
const blogPosts: BlogPost[] = [
  {
    title: "Wie Design Trends 2025 Ihre Website beeinflussen",
    slug: "design-trends-2025",
    category: "Design",
    date: "2025-05-10",
    image: "/placeholder.svg?height=200&width=400",
    excerpt:
      "Entdecken Sie die neuesten Design-Trends, die das Web im Jahr 2025 prägen werden und wie Sie diese für Ihre Website nutzen können.",
    featured: true,
    author: {
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  },
  {
    title: "10 Wesentliche Webdesign-Trends für 2025",
    slug: "essential-web-design-trends-2025",
    category: "Design",
    date: "2025-05-05",
    image: "/placeholder.svg?height=200&width=400",
    excerpt:
      "Bleiben Sie der Konkurrenz voraus mit diesen modernen Webdesign-Trends, die die digitale Landschaft im Jahr 2025 dominieren.",
    featured: false,
    author: {
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  },
  {
    title: "Der ultimative Leitfaden zu Next.js 15",
    slug: "ultimate-guide-nextjs-15",
    category: "Development",
    date: "2025-04-28",
    image: "/placeholder.svg?height=200&width=400",
    excerpt:
      "Alles, was Sie über Next.js 15 wissen müssen, einschließlich neuer Funktionen, Leistungsverbesserungen und Migrationsstrategien.",
    featured: true,
    author: {
      name: "David Wilson",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  },
  {
    title: "Warum Ihr Unternehmen 2025 eine Website benötigt",
    slug: "why-business-needs-website-2025",
    category: "Business",
    date: "2025-04-20",
    image: "/placeholder.svg?height=200&width=400",
    excerpt:
      "In einer zunehmend digitalen Welt ist eine professionelle Website wichtiger denn je. Erfahren Sie, warum Ihr Unternehmen nicht darauf verzichten kann.",
    featured: false,
    author: {
      name: "Lisa Rodriguez",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  },
  {
    title: "Responsive Design für alle Geräte meistern",
    slug: "mastering-responsive-design",
    category: "Design",
    date: "2025-04-15",
    image: "/placeholder.svg?height=200&width=400",
    excerpt:
      "Lernen Sie, wie Sie Websites erstellen, die auf allen Geräten von Smartphones bis hin zu großen Desktop-Monitoren perfekt aussehen und funktionieren.",
    featured: false,
    author: {
      name: "James Taylor",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  },
  {
    title: "SEO-Strategien, die 2025 tatsächlich funktionieren",
    slug: "seo-strategies-2025",
    category: "SEO",
    date: "2025-03-25",
    image: "/placeholder.svg?height=200&width=400",
    excerpt:
      "Durchbrechen Sie den Lärm und konzentrieren Sie sich auf SEO-Techniken, die nachweislich die Sichtbarkeit Ihrer Website in Suchmaschinen verbessern.",
    featured: false,
    author: {
      name: "Olivia Martinez",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  },
  {
    title: "Die Psychologie des Webdesigns: Farben und Konversionen",
    slug: "psychology-web-design-colors",
    category: "Design",
    date: "2025-03-18",
    image: "/placeholder.svg?height=200&width=400",
    excerpt:
      "Wie Farbauswahl das Nutzerverhalten und die Konversionsraten beeinflusst und wie Sie dieses Wissen nutzen können, um die Leistung Ihrer Website zu verbessern.",
    featured: false,
    author: {
      name: "Nathan Park",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  },
  {
    title: "Hochleistungs-E-Commerce-Websites erstellen",
    slug: "high-performance-ecommerce-sites",
    category: "Development",
    date: "2025-04-01",
    image: "/placeholder.svg?height=200&width=400",
    excerpt:
      "Technische Strategien und Best Practices für die Erstellung von E-Commerce-Websites, die schnell laden und Besucher in Kunden umwandeln.",
    featured: false,
    author: {
      name: "Alex Johnson",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  },
  {
    title: "Die Zukunft der Content-Erstellung",
    slug: "future-content-creation",
    category: "SEO",
    date: "2025-04-08",
    image: "/placeholder.svg?height=200&width=400",
    excerpt:
      "Wie moderne Tools die Art und Weise verändern, wie wir Inhalte für Websites erstellen und optimieren, und was dies für Content-Ersteller bedeutet.",
    featured: false,
    author: {
      name: "Emma Davis",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  },
]
