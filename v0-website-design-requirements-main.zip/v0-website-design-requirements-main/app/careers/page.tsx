"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { getBrowserClient } from "@/lib/supabase"
import { Briefcase, Clock, MapPin, Upload } from "lucide-react"

export default function CareersPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const { toast } = useToast()
  const supabase = getBrowserClient()

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    position: "",
    coverLetter: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      let resumeUrl = ""

      // Upload resume if selected
      if (selectedFile) {
        const fileExt = selectedFile.name.split(".").pop()
        const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`
        const filePath = `resumes/${fileName}`

        const { error: uploadError } = await supabase.storage.from("career-files").upload(filePath, selectedFile)

        if (uploadError) {
          throw uploadError
        }

        // Get public URL
        const { data } = supabase.storage.from("career-files").getPublicUrl(filePath)
        resumeUrl = data.publicUrl
      }

      // Save application to database
      const { error } = await supabase.from("career_applications").insert({
        full_name: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        position: formData.position,
        cover_letter: formData.coverLetter,
        resume_url: resumeUrl,
      })

      if (error) {
        throw error
      }

      toast({
        title: "Bewerbung erfolgreich eingereicht",
        description: "Wir werden uns in Kürze mit Ihnen in Verbindung setzen.",
      })

      // Reset form
      setFormData({
        fullName: "",
        email: "",
        phone: "",
        position: "",
        coverLetter: "",
      })
      setSelectedFile(null)
    } catch (error) {
      console.error("Error submitting application:", error)
      toast({
        title: "Fehler",
        description: "Es gab ein Problem bei der Übermittlung Ihrer Bewerbung. Bitte versuchen Sie es später erneut.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-[#0f0a1e] py-20 md:py-32 overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="blob blob-2 animate-rotate" style={{ animationDirection: "reverse" }}></div>
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 animate-fade-in">Karriere bei AfroCraft</h1>
            <p className="text-lg text-white/80 max-w-2xl mx-auto animate-slide-up">
              Werden Sie Teil unseres innovativen Teams und gestalten Sie die digitale Zukunft mit uns.
            </p>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Unser Team</h2>
            <p className="text-muted-foreground text-lg">
              Lernen Sie die Gründer und das Kernteam hinter AfroCraft kennen.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-5xl mx-auto">
            <TeamMember name="Omar Awel" role="Gründer & CEO" image="/placeholder.svg?height=300&width=300" />
            <TeamMember name="Sitra Amdehun" role="Co-Founder & CTO" image="/placeholder.svg?height=300&width=300" />
            <TeamMember
              name="Kidus Wondmagegnehu"
              role="Creative Director"
              image="/placeholder.svg?height=300&width=300"
            />
            <TeamMember name="Ekram Jelau" role="Lead Developer" image="/placeholder.svg?height=300&width=300" />
          </div>
        </div>
      </section>

      {/* Open Positions */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Offene Stellen</h2>
            <p className="text-muted-foreground text-lg">
              Entdecken Sie Ihre Karrieremöglichkeiten bei AfroCraft und bewerben Sie sich noch heute.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <JobCard
              title="Frontend Developer"
              location="Düsseldorf, Deutschland"
              type="Vollzeit"
              description="Wir suchen einen erfahrenen Frontend-Entwickler mit Kenntnissen in React, Next.js und modernen CSS-Frameworks."
            />
            <JobCard
              title="UI/UX Designer"
              location="Remote"
              type="Vollzeit"
              description="Gestalten Sie benutzerfreundliche und ästhetisch ansprechende Interfaces für unsere Kunden und internen Projekte."
            />
            <JobCard
              title="Backend Developer"
              location="Düsseldorf, Deutschland"
              type="Vollzeit"
              description="Entwickeln Sie robuste Backend-Systeme mit Node.js, PostgreSQL und modernen Cloud-Technologien."
            />
            <JobCard
              title="Digital Marketing Specialist"
              location="Hybrid"
              type="Vollzeit"
              description="Planen und implementieren Sie digitale Marketingstrategien, um unsere Marke und Produkte zu fördern."
            />
            <JobCard
              title="Project Manager"
              location="Düsseldorf, Deutschland"
              type="Vollzeit"
              description="Koordinieren Sie Webentwicklungsprojekte von der Konzeption bis zur Fertigstellung und stellen Sie die Kundenzufriedenheit sicher."
            />
            <JobCard
              title="Content Writer"
              location="Remote"
              type="Teilzeit"
              description="Erstellen Sie ansprechende Inhalte für unsere Website, Blog und Social-Media-Kanäle."
            />
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section className="py-20">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Bewerben Sie sich bei uns</h2>
            <p className="text-muted-foreground text-lg">
              Füllen Sie das Formular aus und wir werden uns mit Ihnen in Verbindung setzen.
            </p>
          </div>

          <div className="max-w-2xl mx-auto">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="fullName">
                  Vollständiger Name<span className="text-red-500">*</span>
                </Label>
                <Input id="fullName" name="fullName" value={formData.fullName} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">
                  E-Mail<span className="text-red-500">*</span>
                </Label>
                <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Telefon</Label>
                <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="position">
                  Position<span className="text-red-500">*</span>
                </Label>
                <Input id="position" name="position" value={formData.position} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="resume">
                  Lebenslauf<span className="text-red-500">*</span>
                </Label>
                <div className="flex items-center gap-4">
                  <Input
                    id="resume"
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={handleFileChange}
                    className="hidden"
                    required
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => document.getElementById("resume")?.click()}
                    className="w-full"
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    {selectedFile ? selectedFile.name : "Lebenslauf hochladen"}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">Akzeptierte Formate: PDF, DOC, DOCX. Max. 5MB.</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="coverLetter">Anschreiben</Label>
                <Textarea
                  id="coverLetter"
                  name="coverLetter"
                  value={formData.coverLetter}
                  onChange={handleChange}
                  rows={5}
                />
              </div>

              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "Wird gesendet..." : "Bewerbung absenden"}
              </Button>
            </form>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-[#0f0a1e] text-white relative overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="container relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Warum bei AfroCraft arbeiten?</h2>
            <p className="text-white/80 text-lg">
              Wir bieten mehr als nur einen Job. Entdecken Sie die Vorteile, bei uns zu arbeiten.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">Flexible Arbeitszeiten</h3>
              <p className="text-white/80">
                Wir verstehen, dass jeder unterschiedliche Produktivitätszeiten hat. Arbeiten Sie, wann Sie am besten
                sind.
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">Remote-Möglichkeiten</h3>
              <p className="text-white/80">
                Viele unserer Positionen bieten die Möglichkeit, remote oder hybrid zu arbeiten.
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">Kontinuierliches Lernen</h3>
              <p className="text-white/80">
                Wir investieren in Ihre Weiterbildung mit Zugang zu Kursen, Konferenzen und Workshops.
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">Gesundheitsvorteile</h3>
              <p className="text-white/80">
                Umfassende Gesundheitsversorgung und Wellness-Programme für Sie und Ihre Familie.
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">Teamevents</h3>
              <p className="text-white/80">
                Regelmäßige Teambuilding-Aktivitäten und soziale Events, um Verbindungen zu stärken.
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">Karrierewachstum</h3>
              <p className="text-white/80">
                Klare Karrierewege und Möglichkeiten zur Weiterentwicklung innerhalb des Unternehmens.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

function TeamMember({ name, role, image }: { name: string; role: string; image: string }) {
  return (
    <div className="text-center">
      <div className="relative w-48 h-48 mx-auto rounded-full overflow-hidden mb-4">
        <Image src={image || "/placeholder.svg"} alt={name} fill className="object-cover" />
      </div>
      <h3 className="text-xl font-bold">{name}</h3>
      <p className="text-muted-foreground">{role}</p>
    </div>
  )
}

function JobCard({
  title,
  location,
  type,
  description,
}: { title: string; location: string; type: string; description: string }) {
  return (
    <Card className="hover:shadow-md transition-all">
      <CardContent className="p-6">
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <div className="flex items-center text-sm text-muted-foreground mb-1">
          <MapPin className="h-4 w-4 mr-1" />
          {location}
        </div>
        <div className="flex items-center text-sm text-muted-foreground mb-4">
          <Clock className="h-4 w-4 mr-1" />
          {type}
        </div>
        <p className="text-muted-foreground mb-6">{description}</p>
        <Button asChild className="w-full">
          <Link href="#application-form">
            <Briefcase className="mr-2 h-4 w-4" />
            Jetzt bewerben
          </Link>
        </Button>
      </CardContent>
    </Card>
  )
}
