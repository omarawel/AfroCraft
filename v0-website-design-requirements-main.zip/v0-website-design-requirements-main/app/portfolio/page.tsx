import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function PortfolioPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-[#0f0a1e] py-20 md:py-32 overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="blob blob-2 animate-rotate" style={{ animationDirection: "reverse" }}></div>
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 animate-fade-in">Unsere Arbeiten</h1>
            <p className="text-lg text-white/80 max-w-2xl mx-auto animate-slide-up">
              Entdecken Sie unsere neuesten Projekte und sehen Sie, wie wir Unternehmen dabei helfen, online erfolgreich
              zu sein.
            </p>
          </div>
        </div>
      </section>

      {/* Portfolio Filter */}
      <section className="py-16 -mt-10 relative z-20">
        <div className="container">
          <Tabs defaultValue="all" className="w-full max-w-6xl mx-auto">
            <TabsList className="grid w-full grid-cols-5 mb-12">
              <TabsTrigger value="all">Alle Projekte</TabsTrigger>
              <TabsTrigger value="business">Business</TabsTrigger>
              <TabsTrigger value="ecommerce">E-Commerce</TabsTrigger>
              <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
              <TabsTrigger value="blog">Blog</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects.map((project, index) => (
                  <PortfolioCard key={index} project={project} index={index} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="business" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === "Business")
                  .map((project, index) => (
                    <PortfolioCard key={index} project={project} index={index} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="ecommerce" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === "E-Commerce")
                  .map((project, index) => (
                    <PortfolioCard key={index} project={project} index={index} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="portfolio" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === "Portfolio")
                  .map((project, index) => (
                    <PortfolioCard key={index} project={project} index={index} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="blog" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === "Blog")
                  .map((project, index) => (
                    <PortfolioCard key={index} project={project} index={index} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Unser Prozess</h2>
            <p className="text-muted-foreground text-lg">
              So arbeiten wir mit Ihnen zusammen, um Ihre Vision zum Leben zu erwecken.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="rounded-full bg-primary text-white w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                1
              </div>
              <h3 className="text-xl font-bold mb-2">Entdeckung</h3>
              <p className="text-muted-foreground">
                Wir lernen Ihr Unternehmen, Ihre Ziele und Ihre Zielgruppe kennen.
              </p>
            </div>

            <div className="text-center">
              <div className="rounded-full bg-primary text-white w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                2
              </div>
              <h3 className="text-xl font-bold mb-2">Design</h3>
              <p className="text-muted-foreground">
                Wir erstellen Wireframes und visuelle Designs, die Ihre Marke perfekt repräsentieren.
              </p>
            </div>

            <div className="text-center">
              <div className="rounded-full bg-primary text-white w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                3
              </div>
              <h3 className="text-xl font-bold mb-2">Entwicklung</h3>
              <p className="text-muted-foreground">
                Wir entwickeln Ihre Website mit modernsten Technologien und Best Practices.
              </p>
            </div>

            <div className="text-center">
              <div className="rounded-full bg-primary text-white w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                4
              </div>
              <h3 className="text-xl font-bold mb-2">Launch</h3>
              <p className="text-muted-foreground">
                Wir starten Ihre Website und stellen sicher, dass alles reibungslos funktioniert.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Was unsere Kunden sagen</h2>
            <p className="text-muted-foreground text-lg">
              Erfahren Sie, was unsere Kunden über ihre Erfahrungen mit WebCraft Studio zu sagen haben.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="bg-white border rounded-lg p-6 hover:shadow-md transition-all">
              <CardContent className="p-0">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden bg-primary/10 mr-4">
                    <Image
                      src="/placeholder.svg?height=48&width=48"
                      alt="Client"
                      width={48}
                      height={48}
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold">Sarah Johnson</h4>
                    <p className="text-sm text-muted-foreground">Bloom Boutique</p>
                  </div>
                </div>
                <p className="italic text-muted-foreground">
                  "WebCraft Studio hat unseren Online-Shop komplett transformiert. Die Benutzerfreundlichkeit und das
                  Design haben unsere Verkäufe um 200% gesteigert. Das Team war professionell und hat alle unsere
                  Anforderungen übertroffen."
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white border rounded-lg p-6 hover:shadow-md transition-all">
              <CardContent className="p-0">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden bg-primary/10 mr-4">
                    <Image
                      src="/placeholder.svg?height=48&width=48"
                      alt="Client"
                      width={48}
                      height={48}
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold">Michael Chen</h4>
                    <p className="text-sm text-muted-foreground">Summit Law Partners</p>
                  </div>
                </div>
                <p className="italic text-muted-foreground">
                  "Als Anwaltskanzlei war es uns wichtig, einen professionellen Online-Auftritt zu haben. WebCraft
                  Studio hat genau das geliefert. Die Website ist elegant, funktional und hat unsere Anfragen
                  verdoppelt."
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white border rounded-lg p-6 hover:shadow-md transition-all">
              <CardContent className="p-0">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden bg-primary/10 mr-4">
                    <Image
                      src="/placeholder.svg?height=48&width=48"
                      alt="Client"
                      width={48}
                      height={48}
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold">Lisa Rodriguez</h4>
                    <p className="text-sm text-muted-foreground">Freiberufliche Fotografin</p>
                  </div>
                </div>
                <p className="italic text-muted-foreground">
                  "Mein Portfolio ist jetzt genau so, wie ich es mir vorgestellt habe. Die Bildergalerie präsentiert
                  meine Arbeit perfekt und ich habe zahlreiche neue Kunden gewonnen. Vielen Dank an das gesamte Team!"
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#0f0a1e] text-white relative overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="container text-center max-w-3xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">Bereit für Ihr eigenes Projekt?</h2>
          <p className="text-white/80 text-lg mb-8 animate-slide-up">
            Lassen Sie uns gemeinsam an Ihrer Vision arbeiten und sie zum Leben erwecken.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
            <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
              <Link href="/contact">Kontakt aufnehmen</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
              <Link href="/pricing">Preise ansehen</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

interface Project {
  title: string
  category: string
  image: string
  description: string
  technologies: string[]
  link: string
  client: string
}

function PortfolioCard({ project, index }: { project: Project; index: number }) {
  return (
    <Card
      className="overflow-hidden group hover:shadow-lg transition-all animate-scale"
      style={{ animationDelay: `${index * 0.1}s` }}
    >
      <div className="relative h-64 overflow-hidden">
        <Image
          src={project.image || "/placeholder.svg?height=300&width=400"}
          alt={project.title}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-primary/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Button asChild className="bg-white text-primary hover:bg-white/90">
            <Link href={`/portfolio/${project.link}`}>Projekt ansehen</Link>
          </Button>
        </div>
      </div>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold">{project.title}</h3>
          <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">{project.category}</span>
        </div>
        <p className="text-sm text-muted-foreground mb-2">Kunde: {project.client}</p>
        <p className="text-muted-foreground mb-4 line-clamp-2">{project.description}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {project.technologies.map((tech, i) => (
            <span key={i} className="text-xs bg-secondary px-2 py-1 rounded-full">
              {tech}
            </span>
          ))}
        </div>
        <Link
          href={`/portfolio/${project.link}`}
          className="text-primary font-medium flex items-center hover:underline"
        >
          Fallstudie ansehen <ArrowRight className="h-4 w-4 ml-1" />
        </Link>
      </CardContent>
    </Card>
  )
}

// Sample project data
const projects: Project[] = [
  {
    title: "Bloom Boutique",
    category: "E-Commerce",
    image: "/placeholder.svg?height=300&width=400",
    description:
      "Ein moderner E-Commerce-Shop für eine Modeboutique mit individuellem Warenkorb und Zahlungsintegration.",
    technologies: ["Next.js", "Stripe", "Tailwind CSS", "Vercel"],
    link: "bloom-boutique",
    client: "Bloom Fashion GmbH",
  },
  {
    title: "Urban Gear",
    category: "E-Commerce",
    image: "/placeholder.svg?height=300&width=400",
    description:
      "Ein Online-Shop für Outdoor-Ausrüstung mit Produktfilterung, Kundenbewertungen und sicherem Checkout.",
    technologies: ["React", "Node.js", "MongoDB", "AWS"],
    link: "urban-gear",
    client: "Urban Outdoor Equipment",
  },
  {
    title: "Summit Law",
    category: "Business",
    image: "/placeholder.svg?height=300&width=400",
    description:
      "Eine professionelle Website für eine Anwaltskanzlei mit Informationen zu Dienstleistungen, Anwaltsprofilen und Kontaktformularen.",
    technologies: ["WordPress", "Custom Theme", "PHP", "MySQL"],
    link: "summit-law",
    client: "Summit Law Partners",
  },
  {
    title: "Lisa Rodriguez Fotografie",
    category: "Portfolio",
    image: "/placeholder.svg?height=300&width=400",
    description:
      "Ein beeindruckendes Portfolio für eine professionelle Fotografin mit Bildergalerien und Buchungssystem.",
    technologies: ["Next.js", "Framer Motion", "Sanity CMS", "Vercel"],
    link: "lisa-rodriguez",
    client: "Lisa Rodriguez",
  },
  {
    title: "Evergreen Landscaping",
    category: "Business",
    image: "/placeholder.svg?height=300&width=400",
    description:
      "Eine Website für ein Landschaftsgestaltungsunternehmen mit Dienstleistungsdetails, Projektgalerien und Angebotsanfragen.",
    technologies: ["React", "Firebase", "Tailwind CSS", "Google Cloud"],
    link: "evergreen-landscaping",
    client: "Evergreen Landscaping GmbH",
  },
  {
    title: "Artisan Designs",
    category: "Portfolio",
    image: "/placeholder.svg?height=300&width=400",
    description:
      "Ein kreatives Portfolio für ein Grafikdesign-Studio, das ihre Arbeit und den kreativen Prozess zeigt.",
    technologies: ["Gatsby", "GraphQL", "GSAP", "Netlify"],
    link: "artisan-designs",
    client: "Artisan Design Studio",
  },
  {
    title: "Tech Insights",
    category: "Blog",
    image: "/placeholder.svg?height=300&width=400",
    description: "Ein Technologie-Blog mit kategorisierten Artikeln, Suchfunktion und Newsletter-Abonnement.",
    technologies: ["Next.js", "MDX", "Tailwind CSS", "Vercel"],
    link: "tech-insights",
    client: "TechMedia Group",
  },
  {
    title: "Gourmet Delights",
    category: "Blog",
    image: "/placeholder.svg?height=300&width=400",
    description:
      "Ein Food-Blog mit Rezepten, Kochtipps und Restaurant-Bewertungen mit einem modernen, responsiven Design.",
    technologies: ["Next.js", "Contentful", "Vercel", "Cloudinary"],
    link: "gourmet-delights",
    client: "Gourmet Media",
  },
  {
    title: "Fitness First",
    category: "Business",
    image: "/placeholder.svg?height=300&width=400",
    description: "Eine Website für ein Fitnesscenter mit Kursplan, Mitgliedschaftsinformationen und Online-Buchung.",
    technologies: ["React", "Node.js", "PostgreSQL", "Heroku"],
    link: "fitness-first",
    client: "Fitness First Düsseldorf",
  },
]
