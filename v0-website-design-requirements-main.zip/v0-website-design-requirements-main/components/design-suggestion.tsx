"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Sparkles, Send, Loader2, CheckCircle2 } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DesignSuggestion() {
  const [prompt, setPrompt] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [activeTab, setActiveTab] = useState("input")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim()) return

    setIsLoading(true)

    // Simulate design suggestion response
    setTimeout(() => {
      const designSuggestions = [
        "Für Ihre Unternehmenswebsite empfehlen wir ein klares, professionelles Design mit einer dominanten Farbpalette in Blau- und Grautönen. Ein Hero-Bereich mit einem prägnanten Slogan und Call-to-Action-Button würde die Aufmerksamkeit der Besucher sofort auf sich ziehen.",
        "Basierend auf Ihrer Branche wäre ein minimalistisches Layout mit viel Weißraum und einer klaren Typografie ideal. Wir empfehlen, Ihre Dienstleistungen in einem Raster-Layout mit Icons zu präsentieren, um die Übersichtlichkeit zu verbessern.",
        "Für optimale Konversionsraten sollten Sie Testimonials und Fallstudien prominent platzieren. Ein sticky Header mit Kontaktinformationen würde die Navigation erleichtern und die Benutzerfreundlichkeit verbessern.",
      ]

      setSuggestions(designSuggestions)
      setIsLoading(false)
      setActiveTab("results")
    }, 1500)
  }

  const examplePrompts = [
    "Unternehmenswebsite für eine Marketingagentur",
    "E-Commerce-Shop für Modeartikel",
    "Portfolio für einen freiberuflichen Fotografen",
  ]

  const handleExampleClick = (example: string) => {
    setPrompt(example)
  }

  return (
    <Card className="w-full shadow-lg border-primary/10 overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-primary/90 to-purple-600 text-white">
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-yellow-300" />
          Design-Vorschläge
        </CardTitle>
        <CardDescription className="text-white/80">
          Erhalten Sie maßgeschneiderte Design-Empfehlungen für Ihre Website
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full rounded-none grid grid-cols-2">
            <TabsTrigger value="input">Eingabe</TabsTrigger>
            <TabsTrigger value="results" disabled={suggestions.length === 0 && !isLoading}>
              Ergebnisse
            </TabsTrigger>
          </TabsList>

          <TabsContent value="input" className="p-6 space-y-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="prompt" className="text-sm font-medium">
                  Beschreiben Sie Ihre Website-Anforderungen
                </label>
                <Textarea
                  id="prompt"
                  placeholder="z.B. Ich benötige eine Website für mein Beratungsunternehmen mit Fokus auf professionelles Design..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="min-h-[100px] resize-none"
                />
              </div>

              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Beispiele:</p>
                <div className="flex flex-wrap gap-2">
                  {examplePrompts.map((example, index) => (
                    <button
                      key={index}
                      type="button"
                      className="text-xs px-3 py-1.5 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
                      onClick={() => handleExampleClick(example)}
                    >
                      {example}
                    </button>
                  ))}
                </div>
              </div>

              <Button
                type="submit"
                className="w-full flex items-center gap-2 bg-primary hover:bg-primary/90 text-white"
                disabled={isLoading || !prompt.trim()}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Generiere Vorschläge...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    Vorschläge erhalten
                  </>
                )}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="results" className="p-6 space-y-6">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-8">
                <Loader2 className="h-8 w-8 text-primary animate-spin mb-4" />
                <p className="text-muted-foreground">Generiere Design-Vorschläge...</p>
              </div>
            ) : (
              <>
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Design-Empfehlungen</h3>
                  {suggestions.map((suggestion, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-lg border border-gray-100">
                      <div className="flex gap-2">
                        <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                        <p className="text-sm">{suggestion}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={() => setActiveTab("input")}>
                    Zurück zur Eingabe
                  </Button>
                  <Button className="bg-primary hover:bg-primary/90 text-white">Alle Vorschläge speichern</Button>
                </div>
              </>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
