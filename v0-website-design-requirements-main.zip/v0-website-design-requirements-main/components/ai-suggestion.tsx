"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Sparkles, Send, Loader2 } from "lucide-react"

export default function AISuggestion() {
  const [prompt, setPrompt] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [suggestion, setSuggestion] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim()) return

    setIsLoading(true)

    // Simulate AI response
    setTimeout(() => {
      const suggestions = [
        "Consider adding a hero section with a clear value proposition and a strong call-to-action button.",
        "Your website could benefit from customer testimonials to build trust with potential clients.",
        "Adding a portfolio section would showcase your previous work and demonstrate your expertise.",
        "Consider implementing a blog to improve SEO and establish your authority in the industry.",
        "A clear pricing section would help potential clients understand your service offerings.",
      ]

      setSuggestion(suggestions[Math.floor(Math.random() * suggestions.length)])
      setIsLoading(false)
    }, 1500)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-yellow-500" />
          AI Website Suggestions
        </CardTitle>
        <CardDescription>Get personalized recommendations for your website from our AI assistant.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Textarea
              placeholder="Describe your business and website goals..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="min-h-[100px]"
            />
          </div>
          <Button type="submit" className="w-full flex items-center gap-2" disabled={isLoading || !prompt.trim()}>
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Generating suggestion...
              </>
            ) : (
              <>
                <Send className="h-4 w-4" />
                Get Suggestion
              </>
            )}
          </Button>
        </form>

        {suggestion && (
          <div className="mt-6 p-4 bg-muted/50 rounded-lg">
            <h4 className="font-medium mb-2">AI Suggestion:</h4>
            <p className="text-muted-foreground">{suggestion}</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
