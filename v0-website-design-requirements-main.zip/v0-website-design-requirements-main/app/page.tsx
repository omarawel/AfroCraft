import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sparkles, ArrowRight, Zap, Code, Layout, Palette, CheckCircle2 } from "lucide-react"
import DesignSuggestion from "@/components/design-suggestion"
import { ChatbotWidget } from "@/components/chatbot-widget"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-[#0f0a1e] py-20 md:py-32 overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="blob blob-2 animate-rotate" style={{ animationDirection: "reverse" }}></div>
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight text-white animate-fade-in">
              <span className="block">Turn website ideas</span>
              <span className="block">
                into <span className="text-primary">concepts instantly</span>
              </span>
            </h1>
            <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto animate-slide-up">
              Visualisieren, kommunizieren und iterieren Sie Website-Designs in Minuten. Stärken Sie Ihr Unternehmen mit
              professionellen Designs!
            </p>

            <div
              className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up"
              style={{ animationDelay: "0.2s" }}
            >
              <div className="relative flex-1 max-w-xl">
                <Input
                  placeholder="Beschreiben Sie Ihre Website-Idee..."
                  className="w-full h-12 pl-4 pr-32 rounded-md border-0 bg-white/10 backdrop-blur-sm text-white placeholder:text-white/50"
                />
                <Button className="absolute right-1 top-1 h-10 bg-primary hover:bg-primary/90 gap-1">
                  <Sparkles className="h-4 w-4" />
                  <span>Generieren</span>
                </Button>
              </div>
            </div>

            <div className="pt-8 animate-slide-up" style={{ animationDelay: "0.3s" }}>
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 inline-block">
                <p className="text-sm text-white/70">
                  Vertraut von <span className="font-medium text-white">500+</span> Unternehmen in Deutschland
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Leistungsstarke Funktionen für Ihre Website</h2>
            <p className="text-muted-foreground text-lg">
              Unsere Plattform bietet alles, was Sie benötigen, um atemberaubende, funktionale Websites zu erstellen.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <div
              className="bg-white border rounded-lg p-6 hover:shadow-md transition-all animate-scale"
              style={{ animationDelay: "0.1s" }}
            >
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Zap className="text-primary h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Professionelles Design</h3>
              <p className="text-muted-foreground mb-4">
                Generieren Sie professionelle Website-Designs aus einfachen Textbeschreibungen mit unserer
                fortschrittlichen Technologie.
              </p>
              <Link href="/product" className="text-primary font-medium flex items-center hover:underline">
                Mehr erfahren <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>

            <div
              className="bg-white border rounded-lg p-6 hover:shadow-md transition-all animate-scale"
              style={{ animationDelay: "0.2s" }}
            >
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Code className="text-primary h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Saubere Code-Generierung</h3>
              <p className="text-muted-foreground mb-4">
                Exportieren Sie Ihre Designs als sauberen, optimierten Code, der für jede moderne Hosting-Plattform
                bereit ist.
              </p>
              <Link href="/product" className="text-primary font-medium flex items-center hover:underline">
                Mehr erfahren <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>

            <div
              className="bg-white border rounded-lg p-6 hover:shadow-md transition-all animate-scale"
              style={{ animationDelay: "0.3s" }}
            >
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Layout className="text-primary h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Responsive Templates</h3>
              <p className="text-muted-foreground mb-4">
                Wählen Sie aus Hunderten von professionell gestalteten Vorlagen, die auf allen Geräten großartig
                aussehen.
              </p>
              <Link href="/templates" className="text-primary font-medium flex items-center hover:underline">
                Mehr erfahren <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>

            <div
              className="bg-white border rounded-lg p-6 hover:shadow-md transition-all animate-scale"
              style={{ animationDelay: "0.4s" }}
            >
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Palette className="text-primary h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Anpassung</h3>
              <p className="text-muted-foreground mb-4">
                Passen Sie jeden Aspekt Ihrer Website ganz einfach mit unserer intuitiven Drag-and-Drop-Oberfläche an.
              </p>
              <Link href="/product" className="text-primary font-medium flex items-center hover:underline">
                Mehr erfahren <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>

            <div
              className="bg-white border rounded-lg p-6 hover:shadow-md transition-all animate-scale"
              style={{ animationDelay: "0.5s" }}
            >
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <CheckCircle2 className="text-primary h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">SEO-Optimierung</h3>
              <p className="text-muted-foreground mb-4">
                Integrierte SEO-Tools, die Ihrer Website helfen, in den Suchmaschinenergebnissen höher zu ranken.
              </p>
              <Link href="/product" className="text-primary font-medium flex items-center hover:underline">
                Mehr erfahren <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>

            <div
              className="bg-white border rounded-lg p-6 hover:shadow-md transition-all animate-scale"
              style={{ animationDelay: "0.6s" }}
            >
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Sparkles className="text-primary h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Design-Vorschläge</h3>
              <p className="text-muted-foreground mb-4">
                Erhalten Sie intelligente Design-Vorschläge, um das Engagement und die Konversionsraten Ihrer Website zu
                verbessern.
              </p>
              <Link href="/product" className="text-primary font-medium flex items-center hover:underline">
                Mehr erfahren <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Wie es funktioniert</h2>
            <p className="text-muted-foreground text-lg">
              Die Erstellung Ihrer perfekten Website ist mit unserem optimierten Prozess einfach.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center animate-float">
              <div className="rounded-full bg-primary text-white w-12 h-12 flex items-center justify-center mx-auto mb-4">
                1
              </div>
              <h3 className="text-xl font-bold mb-2">Beschreiben Sie Ihre Vision</h3>
              <p className="text-muted-foreground">
                Teilen Sie uns mit, welche Art von Website Sie benötigen, Ihren Markenstil und wichtige Funktionen.
              </p>
            </div>

            <div className="text-center animate-float" style={{ animationDelay: "0.5s" }}>
              <div className="rounded-full bg-primary text-white w-12 h-12 flex items-center justify-center mx-auto mb-4">
                2
              </div>
              <h3 className="text-xl font-bold mb-2">Überprüfen & Anpassen</h3>
              <p className="text-muted-foreground">
                Durchsuchen Sie generierte Designs und passen Sie sie an Ihre genauen Anforderungen an.
              </p>
            </div>

            <div className="text-center animate-float" style={{ animationDelay: "1s" }}>
              <div className="rounded-full bg-primary text-white w-12 h-12 flex items-center justify-center mx-auto mb-4">
                3
              </div>
              <h3 className="text-xl font-bold mb-2">Veröffentlichen & Wachsen</h3>
              <p className="text-muted-foreground">
                Starten Sie Ihre Website mit einem Klick und beginnen Sie, Kunden für Ihr Unternehmen zu gewinnen.
              </p>
            </div>
          </div>

          <div className="mt-16 text-center">
            <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-white">
              <Link href="/signup">Kostenlos starten</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Design Suggestion Section */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 animate-slide-in-left">
              <h2 className="text-3xl md:text-4xl font-bold">Erhalten Sie professionelle Design-Vorschläge</h2>
              <p className="text-muted-foreground">
                Unser Tool analysiert Ihre Anforderungen und generiert maßgeschneiderte Design-Vorschläge, die perfekt
                zu Ihrer Marke passen. Sparen Sie Zeit und Ressourcen bei der Erstellung Ihrer Website.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Personalisierte Design-Empfehlungen</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Branchenspezifische Vorlagen</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Farbschema-Vorschläge basierend auf Ihrer Marke</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Layout-Optimierungen für bessere Konversionen</span>
                </li>
              </ul>
              <Button asChild className="bg-primary hover:bg-primary/90 text-white">
                <Link href="/product">Mehr erfahren</Link>
              </Button>
            </div>
            <div className="animate-slide-in-right">
              <DesignSuggestion />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Was unsere Kunden sagen</h2>
            <p className="text-muted-foreground text-lg">
              Hören Sie von Unternehmen, die ihre Online-Präsenz mit WebCraft Studio transformiert haben.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white border rounded-lg p-6 animate-pulse-slow">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full overflow-hidden bg-primary/10 mr-4">
                  <Image
                    src="/placeholder.svg?height=48&width=48"
                    alt="Client"
                    width={48}
                    height={48}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-bold">Sarah Johnson</h4>
                  <p className="text-sm text-muted-foreground">Kleinunternehmerin</p>
                </div>
              </div>
              <p className="italic text-muted-foreground">
                "WebCraft Studio hat unsere veraltete Website in eine moderne, benutzerfreundliche Plattform verwandelt,
                die unsere Marke perfekt repräsentiert. Die Design-Vorschläge waren genau richtig und haben uns
                unzählige Arbeitsstunden erspart."
              </p>
            </div>

            <div className="bg-white border rounded-lg p-6 animate-pulse-slow" style={{ animationDelay: "1s" }}>
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full overflow-hidden bg-primary/10 mr-4">
                  <Image
                    src="/placeholder.svg?height=48&width=48"
                    alt="Client"
                    width={48}
                    height={48}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-bold">Michael Chen</h4>
                  <p className="text-sm text-muted-foreground">Marketing Direktor</p>
                </div>
              </div>
              <p className="italic text-muted-foreground">
                "Die Geschwindigkeit, mit der wir unsere neue Website starten konnten, war unglaublich. Was mit
                herkömmlichen Methoden Monate gedauert hätte, dauerte mit WebCraft Studio nur wenige Tage. Die
                Ergebnisse übertrafen unsere Erwartungen."
              </p>
            </div>

            <div className="bg-white border rounded-lg p-6 animate-pulse-slow" style={{ animationDelay: "2s" }}>
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full overflow-hidden bg-primary/10 mr-4">
                  <Image
                    src="/placeholder.svg?height=48&width=48"
                    alt="Client"
                    width={48}
                    height={48}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-bold">Lisa Rodriguez</h4>
                  <p className="text-sm text-muted-foreground">Freiberufliche Fotografin</p>
                </div>
              </div>
              <p className="italic text-muted-foreground">
                "Als Kreativprofi brauchte ich ein Portfolio, das meine Arbeit wunderschön präsentiert. WebCraft Studio
                hat genau das geliefert, was ich brauchte, und ich habe unzählige Komplimente für meine neue Website
                erhalten."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#0f0a1e] text-white relative overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="container text-center max-w-3xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">
            Bereit, Ihre Traumwebsite zu erstellen?
          </h2>
          <p className="text-white/80 text-lg mb-8 animate-slide-up">
            Schließen Sie sich zufriedenen Kunden an, die ihre Online-Präsenz mit WebCraft Studio transformiert haben.
          </p>
          <div
            className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up"
            style={{ animationDelay: "0.2s" }}
          >
            <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
              <Link href="/signup">Kostenlos starten</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
              <Link href="/portfolio">Unsere Arbeit ansehen</Link>
            </Button>
          </div>
        </div>
      </section>
      <ChatbotWidget />
    </div>
  )
}
