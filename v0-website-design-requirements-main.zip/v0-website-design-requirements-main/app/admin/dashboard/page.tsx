"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  PieChart,
  Users,
  FileText,
  MessageSquare,
  Calendar,
  Settings,
  Plus,
  Search,
  Download,
  Pencil,
  Trash2,
  Eye,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AdminSidebar } from "@/components/admin-sidebar"

export default function AdminDashboardPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar />

      <div className="flex-1 p-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">Willkommen zurück, Admin. Hier ist eine Übersicht Ihrer Daten.</p>
          </div>
          <div className="flex gap-2">
            <Button asChild className="bg-primary hover:bg-primary/90">
              <Link href="/admin/dashboard/new-project">
                <Plus className="h-4 w-4 mr-2" />
                Neues Projekt
              </Link>
            </Button>
            <Button variant="outline">
              <Settings className="h-4 w-4 mr-2" />
              Einstellungen
            </Button>
          </div>
        </div>

        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid grid-cols-4 w-full max-w-2xl">
            <TabsTrigger value="overview">Übersicht</TabsTrigger>
            <TabsTrigger value="blog">Blog</TabsTrigger>
            <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
            <TabsTrigger value="contacts">Kontakte</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Kunden</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">42</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-500">↑ 12%</span> seit letztem Monat
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Aktive Projekte</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">18</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-500">↑ 8%</span> seit letztem Monat
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Monatlicher Umsatz</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">€24,500</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-500">↑ 15%</span> seit letztem Monat
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Support-Tickets</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">7</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-red-500">↑ 3</span> ungelöst
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Umsatzübersicht</CardTitle>
                  <CardDescription>Monatlicher Umsatz für das laufende Jahr</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80 flex items-center justify-center bg-muted/20 rounded-md">
                    <BarChart className="h-16 w-16 text-muted-foreground" />
                    <span className="ml-4 text-muted-foreground">Umsatzdiagramm würde hier erscheinen</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Projektverteilung</CardTitle>
                  <CardDescription>Projekte nach Kategorie</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <div className="flex items-center justify-center h-48 bg-muted/20 rounded-md mb-4">
                      <PieChart className="h-16 w-16 text-muted-foreground" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <div className="w-3 h-3 rounded-full bg-primary mr-2"></div>
                        <span className="text-sm">Business Websites (45%)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
                        <span className="text-sm">E-Commerce (30%)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                        <span className="text-sm">Portfolios (15%)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                        <span className="text-sm">Blogs (10%)</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Neueste Aktivitäten</CardTitle>
                <CardDescription>Die letzten Aktionen und Updates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {activities.map((activity, index) => (
                    <div key={index} className="flex">
                      <div className="relative mr-4">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                          {activity.icon}
                        </div>
                        {index !== activities.length - 1 && (
                          <div className="absolute bottom-0 left-1/2 top-10 w-px -translate-x-1/2 bg-border"></div>
                        )}
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <p className="text-sm font-medium">{activity.title}</p>
                        <p className="text-sm text-muted-foreground">{activity.description}</p>
                        <p className="text-xs text-muted-foreground">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="blog" className="space-y-8">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Blog-Verwaltung</CardTitle>
                    <CardDescription>Verwalten Sie Ihre Blog-Beiträge</CardDescription>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Beiträge durchsuchen..."
                        className="pl-8"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    <Select defaultValue="all">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Nach Kategorie filtern" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Alle Kategorien</SelectItem>
                        <SelectItem value="design">Design</SelectItem>
                        <SelectItem value="development">Entwicklung</SelectItem>
                        <SelectItem value="seo">SEO</SelectItem>
                        <SelectItem value="business">Business</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button asChild className="bg-primary hover:bg-primary/90">
                      <Link href="/admin/dashboard/blog/new">
                        <Plus className="h-4 w-4 mr-2" />
                        Neuer Beitrag
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <div className="relative w-full overflow-auto">
                    <table className="w-full caption-bottom text-sm">
                      <thead>
                        <tr className="border-b bg-muted/50">
                          <th className="h-12 px-4 text-left align-middle font-medium">Titel</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Kategorie</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Autor</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Datum</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Status</th>
                          <th className="h-12 px-4 text-right align-middle font-medium">Aktionen</th>
                        </tr>
                      </thead>
                      <tbody>
                        {blogPosts.map((post, index) => (
                          <tr key={index} className="border-b">
                            <td className="p-4 align-middle">
                              <div className="font-medium">{post.title}</div>
                            </td>
                            <td className="p-4 align-middle">{post.category}</td>
                            <td className="p-4 align-middle">{post.author}</td>
                            <td className="p-4 align-middle">{post.date}</td>
                            <td className="p-4 align-middle">
                              <div
                                className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                                  post.status === "Veröffentlicht"
                                    ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                    : post.status === "Entwurf"
                                      ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                                      : "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
                                }`}
                              >
                                {post.status}
                              </div>
                            </td>
                            <td className="p-4 align-middle text-right">
                              <div className="flex justify-end gap-2">
                                <Button variant="ghost" size="icon">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon">
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="flex items-center justify-end space-x-2 py-4">
                  <Button variant="outline" size="sm">
                    Vorherige
                  </Button>
                  <Button variant="outline" size="sm">
                    Nächste
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="portfolio" className="space-y-8">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Portfolio-Verwaltung</CardTitle>
                    <CardDescription>Verwalten Sie Ihre Portfolio-Projekte</CardDescription>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Projekte durchsuchen..."
                        className="pl-8"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    <Select defaultValue="all">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Nach Kategorie filtern" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Alle Kategorien</SelectItem>
                        <SelectItem value="website">Website</SelectItem>
                        <SelectItem value="ecommerce">E-Commerce</SelectItem>
                        <SelectItem value="app">App</SelectItem>
                        <SelectItem value="branding">Branding</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button asChild className="bg-primary hover:bg-primary/90">
                      <Link href="/admin/dashboard/portfolio/new">
                        <Plus className="h-4 w-4 mr-2" />
                        Neues Projekt
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {portfolioProjects.map((project, index) => (
                    <Card key={index} className="overflow-hidden">
                      <div className="relative h-48">
                        <Image
                          src={project.image || "/placeholder.svg?height=200&width=400"}
                          alt={project.title}
                          fill
                          className="object-cover"
                        />
                        <div className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                          <Button variant="outline" size="sm" className="text-white border-white hover:bg-white/20">
                            <Eye className="h-4 w-4 mr-1" /> Ansehen
                          </Button>
                          <Button variant="outline" size="sm" className="text-white border-white hover:bg-white/20">
                            <Pencil className="h-4 w-4 mr-1" /> Bearbeiten
                          </Button>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-semibold">{project.title}</h3>
                        <p className="text-sm text-muted-foreground">{project.category}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="contacts" className="space-y-8">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Kontaktverwaltung</CardTitle>
                    <CardDescription>Verwalten Sie Ihre Kontaktanfragen</CardDescription>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Anfragen durchsuchen..."
                        className="pl-8"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    <Select defaultValue="all">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Nach Status filtern" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Alle Anfragen</SelectItem>
                        <SelectItem value="new">Neu</SelectItem>
                        <SelectItem value="in-progress">In Bearbeitung</SelectItem>
                        <SelectItem value="resolved">Erledigt</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      Exportieren
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <div className="relative w-full overflow-auto">
                    <table className="w-full caption-bottom text-sm">
                      <thead>
                        <tr className="border-b bg-muted/50">
                          <th className="h-12 px-4 text-left align-middle font-medium">Name</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">E-Mail</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Betreff</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Datum</th>
                          <th className="h-12 px-4 text-left align-middle font-medium">Status</th>
                          <th className="h-12 px-4 text-right align-middle font-medium">Aktionen</th>
                        </tr>
                      </thead>
                      <tbody>
                        {contactRequests.map((request, index) => (
                          <tr key={index} className="border-b">
                            <td className="p-4 align-middle">
                              <div className="font-medium">{request.name}</div>
                            </td>
                            <td className="p-4 align-middle">{request.email}</td>
                            <td className="p-4 align-middle">{request.subject}</td>
                            <td className="p-4 align-middle">{request.date}</td>
                            <td className="p-4 align-middle">
                              <div
                                className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                                  request.status === "Neu"
                                    ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
                                    : request.status === "In Bearbeitung"
                                      ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                                      : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                }`}
                              >
                                {request.status}
                              </div>
                            </td>
                            <td className="p-4 align-middle text-right">
                              <div className="flex justify-end gap-2">
                                <Button variant="ghost" size="icon">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon">
                                  <MessageSquare className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="flex items-center justify-end space-x-2 py-4">
                  <Button variant="outline" size="sm">
                    Vorherige
                  </Button>
                  <Button variant="outline" size="sm">
                    Nächste
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

const activities = [
  {
    icon: <FileText className="h-5 w-5 text-primary" />,
    title: "Neues Projekt erstellt",
    description: "E-Commerce-Website für Acme Corporation",
    time: "Vor 1 Stunde",
  },
  {
    icon: <Users className="h-5 w-5 text-primary" />,
    title: "Neuer Kunde registriert",
    description: "Stark Enterprises hat sich für einen Pro-Plan angemeldet",
    time: "Vor 3 Stunden",
  },
  {
    icon: <MessageSquare className="h-5 w-5 text-primary" />,
    title: "Neues Support-Ticket",
    description: "Globex Industries hat ein Problem mit ihrem Kontaktformular gemeldet",
    time: "Vor 5 Stunden",
  },
  {
    icon: <Calendar className="h-5 w-5 text-primary" />,
    title: "Meeting geplant",
    description: "Projekt-Kickoff-Meeting mit Wayne Industries",
    time: "Gestern",
  },
  {
    icon: <Settings className="h-5 w-5 text-primary" />,
    title: "Systemupdate abgeschlossen",
    description: "Plattform auf Version 2.4.0 aktualisiert",
    time: "Vor 2 Tagen",
  },
]

const blogPosts = [
  {
    title: "Wie Design Trends 2025 Ihre Website beeinflussen",
    category: "Design",
    author: "Sarah Johnson",
    date: "10.05.2025",
    status: "Veröffentlicht",
  },
  {
    title: "10 Wesentliche Webdesign-Trends für 2025",
    category: "Design",
    author: "Michael Chen",
    date: "05.05.2025",
    status: "Veröffentlicht",
  },
  {
    title: "Der ultimative Leitfaden zu Next.js 15",
    category: "Development",
    author: "David Wilson",
    date: "28.04.2025",
    status: "Veröffentlicht",
  },
  {
    title: "SEO-Strategien, die 2025 tatsächlich funktionieren",
    category: "SEO",
    author: "Olivia Martinez",
    date: "25.03.2025",
    status: "Veröffentlicht",
  },
  {
    title: "Die Zukunft des E-Commerce",
    category: "Business",
    author: "Thomas Schmidt",
    date: "15.05.2025",
    status: "Entwurf",
  },
  {
    title: "Barrierefreies Webdesign: Ein umfassender Leitfaden",
    category: "Design",
    author: "Julia Weber",
    date: "20.05.2025",
    status: "Geplant",
  },
]

const portfolioProjects = [
  {
    title: "Acme Corporation Website",
    category: "Business Website",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    title: "Globex E-Commerce Shop",
    category: "E-Commerce",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    title: "Stark Enterprises Branding",
    category: "Branding",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    title: "Wayne Industries Portfolio",
    category: "Portfolio",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    title: "Umbrella Corp App",
    category: "Mobile App",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    title: "Daily Planet News Blog",
    category: "Blog",
    image: "/placeholder.svg?height=200&width=400",
  },
]

const contactRequests = [
  {
    name: "Max Mustermann",
    email: "max@example.com",
    subject: "Website-Anfrage für mein Unternehmen",
    date: "13.05.2025",
    status: "Neu",
  },
  {
    name: "Laura Schmidt",
    email: "laura@example.com",
    subject: "Frage zum Premium-Paket",
    date: "12.05.2025",
    status: "In Bearbeitung",
  },
  {
    name: "Thomas Weber",
    email: "thomas@example.com",
    subject: "Demo-Anfrage für E-Commerce-Lösung",
    date: "10.05.2025",
    status: "Erledigt",
  },
  {
    name: "Anna Müller",
    email: "anna@example.com",
    subject: "Preisanfrage für individuelles Projekt",
    date: "09.05.2025",
    status: "In Bearbeitung",
  },
  {
    name: "Michael Becker",
    email: "michael@example.com",
    subject: "Frage zur Wartung meiner Website",
    date: "08.05.2025",
    status: "Erledigt",
  },
]
