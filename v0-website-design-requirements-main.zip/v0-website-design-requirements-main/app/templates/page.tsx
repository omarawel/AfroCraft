import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Search, ArrowRight } from "lucide-react"

export default function TemplatesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-[#0f0a1e] py-20 md:py-32 overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="blob blob-2 animate-rotate" style={{ animationDirection: "reverse" }}></div>
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight text-white animate-fade-in">
              <span className="block">Professionelle Templates</span>
              <span className="block">
                für <span className="text-primary">jeden Bedarf</span>
              </span>
            </h1>
            <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto animate-slide-up">
              Wählen Sie aus Hunderten von professionell gestalteten Templates, die perfekt zu Ihrem Projekt passen.
            </p>

            <div className="relative max-w-xl mx-auto animate-slide-up">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Suchen Sie nach Templates..."
                  className="pl-10 h-12 bg-white/10 backdrop-blur-sm text-white border-0 placeholder:text-white/50 focus-visible:ring-primary"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Templates Filter */}
      <section className="py-12">
        <div className="container">
          <Tabs defaultValue="all" className="w-full max-w-4xl mx-auto mb-12">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="all">Alle</TabsTrigger>
              <TabsTrigger value="business">Business</TabsTrigger>
              <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
              <TabsTrigger value="ecommerce">E-Commerce</TabsTrigger>
              <TabsTrigger value="blog">Blog</TabsTrigger>
              <TabsTrigger value="landing">Landing Page</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {templates.map((template, index) => (
                  <TemplateCard key={index} template={template} index={index} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="business" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {templates
                  .filter((template) => template.category === "Business")
                  .map((template, index) => (
                    <TemplateCard key={index} template={template} index={index} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="portfolio" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {templates
                  .filter((template) => template.category === "Portfolio")
                  .map((template, index) => (
                    <TemplateCard key={index} template={template} index={index} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="ecommerce" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {templates
                  .filter((template) => template.category === "E-Commerce")
                  .map((template, index) => (
                    <TemplateCard key={index} template={template} index={index} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="blog" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {templates
                  .filter((template) => template.category === "Blog")
                  .map((template, index) => (
                    <TemplateCard key={index} template={template} index={index} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="landing" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {templates
                  .filter((template) => template.category === "Landing Page")
                  .map((template, index) => (
                    <TemplateCard key={index} template={template} index={index} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex justify-center mt-12">
            <Button variant="outline" className="mr-2">
              Vorherige
            </Button>
            <Button variant="outline">Nächste</Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#0f0a1e] text-white relative overflow-hidden mt-12">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="container text-center max-w-3xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">Finden Sie nicht das Richtige?</h2>
          <p className="text-white/80 text-lg mb-8 animate-slide-up">
            Wir können ein maßgeschneidertes Template für Ihre spezifischen Anforderungen erstellen.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
            <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
              <Link href="/contact">Individuelles Angebot anfragen</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

interface Template {
  title: string
  category: string
  image: string
  popular: boolean
  new: boolean
  price: string
  link: string
}

function TemplateCard({ template, index }: { template: Template; index: number }) {
  return (
    <Card
      className="overflow-hidden group hover:shadow-lg transition-all animate-scale"
      style={{ animationDelay: `${index * 0.1}s` }}
    >
      <div className="relative h-64 overflow-hidden">
        <Image
          src={template.image || "/placeholder.svg?height=300&width=400"}
          alt={template.title}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
        {template.popular && (
          <div className="absolute top-2 left-2 bg-primary text-white text-xs px-2 py-1 rounded-full">Beliebt</div>
        )}
        {template.new && (
          <div className="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full">Neu</div>
        )}
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Button asChild className="bg-white text-primary hover:bg-white/90">
            <Link href={`/templates/${template.link}`}>Vorschau</Link>
          </Button>
        </div>
      </div>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-bold">{template.title}</h3>
          <span className="text-sm bg-primary/10 text-primary px-2 py-1 rounded-full">{template.category}</span>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <span className="font-medium">{template.price}</span>
        <Link
          href={`/templates/${template.link}`}
          className="text-primary font-medium flex items-center hover:underline"
        >
          Details <ArrowRight className="h-4 w-4 ml-1" />
        </Link>
      </CardFooter>
    </Card>
  )
}

// Sample template data
const templates: Template[] = [
  {
    title: "Business Pro",
    category: "Business",
    image: "/placeholder.svg?height=300&width=400",
    popular: true,
    new: false,
    price: "€99",
    link: "business-pro",
  },
  {
    title: "Creative Portfolio",
    category: "Portfolio",
    image: "/placeholder.svg?height=300&width=400",
    popular: false,
    new: true,
    price: "€79",
    link: "creative-portfolio",
  },
  {
    title: "E-Shop",
    category: "E-Commerce",
    image: "/placeholder.svg?height=300&width=400",
    popular: true,
    new: false,
    price: "€149",
    link: "e-shop",
  },
  {
    title: "Blog Standard",
    category: "Blog",
    image: "/placeholder.svg?height=300&width=400",
    popular: false,
    new: false,
    price: "€69",
    link: "blog-standard",
  },
  {
    title: "Landing Pro",
    category: "Landing Page",
    image: "/placeholder.svg?height=300&width=400",
    popular: false,
    new: true,
    price: "€59",
    link: "landing-pro",
  },
  {
    title: "Corporate Plus",
    category: "Business",
    image: "/placeholder.svg?height=300&width=400",
    popular: false,
    new: false,
    price: "€119",
    link: "corporate-plus",
  },
  {
    title: "Artist Showcase",
    category: "Portfolio",
    image: "/placeholder.svg?height=300&width=400",
    popular: false,
    new: false,
    price: "€89",
    link: "artist-showcase",
  },
  {
    title: "Fashion Store",
    category: "E-Commerce",
    image: "/placeholder.svg?height=300&width=400",
    popular: true,
    new: false,
    price: "€129",
    link: "fashion-store",
  },
  {
    title: "Magazine Theme",
    category: "Blog",
    image: "/placeholder.svg?height=300&width=400",
    popular: false,
    new: false,
    price: "€79",
    link: "magazine-theme",
  },
]
