"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/lib/auth-context"
import { getBrowserClient } from "@/lib/supabase"
import { ArrowRight, CheckCircle, Copy, DollarSign, Share2, Users } from "lucide-react"

export default function AffiliatePage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [referralCode, setReferralCode] = useState("")
  const [affiliateStats, setAffiliateStats] = useState({
    referrals: 0,
    pendingCommission: 0,
    totalEarnings: 0,
  })
  const supabase = getBrowserClient()

  const handleJoinProgram = async () => {
    if (!user) {
      toast({
        title: "Anmeldung erforderlich",
        description: "Bitte melden Sie sich an oder registrieren Sie sich, um am Partnerprogramm teilzunehmen.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // Generate a unique referral code
      const code = `AFRO-${Math.random().toString(36).substring(2, 8).toUpperCase()}`

      // Save to database
      const { error } = await supabase.from("affiliates").insert({
        user_id: user.id,
        referral_code: code,
      })

      if (error) {
        throw error
      }

      setReferralCode(code)
      toast({
        title: "Erfolgreich beigetreten!",
        description: "Sie sind jetzt Teil unseres Partnerprogramms.",
      })
    } catch (error) {
      console.error("Error joining affiliate program:", error)
      toast({
        title: "Fehler",
        description: "Es gab ein Problem beim Beitritt zum Partnerprogramm. Bitte versuchen Sie es später erneut.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const copyReferralLink = () => {
    const link = `https://afrocraft.com/signup?ref=${referralCode}`
    navigator.clipboard.writeText(link)
    toast({
      title: "Link kopiert!",
      description: "Der Empfehlungslink wurde in die Zwischenablage kopiert.",
    })
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-[#0f0a1e] py-20 md:py-32 overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="blob blob-2 animate-rotate" style={{ animationDirection: "reverse" }}></div>
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 animate-fade-in">Partnerprogramm</h1>
            <p className="text-lg text-white/80 max-w-2xl mx-auto animate-slide-up">
              Verdienen Sie Provisionen, indem Sie Kunden zu AfroCraft empfehlen. Einfach, transparent und profitabel.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
              <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
                <a href="#join">Jetzt beitreten</a>
              </Button>
              <Button asChild size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
                <a href="#how-it-works">Wie es funktioniert</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Wie es funktioniert</h2>
            <p className="text-muted-foreground text-lg">
              Unser Partnerprogramm ist einfach zu nutzen und bietet großartige Verdienstmöglichkeiten.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card>
              <CardContent className="pt-6">
                <div className="rounded-full bg-primary/10 text-primary w-12 h-12 flex items-center justify-center mb-4">
                  <Users className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">1. Registrieren</h3>
                <p className="text-muted-foreground">
                  Melden Sie sich an und treten Sie unserem Partnerprogramm bei. Sie erhalten einen einzigartigen
                  Empfehlungscode.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="rounded-full bg-primary/10 text-primary w-12 h-12 flex items-center justify-center mb-4">
                  <Share2 className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">2. Teilen</h3>
                <p className="text-muted-foreground">
                  Teilen Sie Ihren Empfehlungslink mit potenziellen Kunden über soziale Medien, E-Mail oder Ihre
                  Website.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="rounded-full bg-primary/10 text-primary w-12 h-12 flex items-center justify-center mb-4">
                  <DollarSign className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">3. Verdienen</h3>
                <p className="text-muted-foreground">
                  Verdienen Sie 10% Provision für jeden Kunden, der sich über Ihren Link anmeldet und ein Abonnement
                  abschließt.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Vorteile unseres Partnerprogramms</h2>
            <p className="text-muted-foreground text-lg">
              Warum Sie sich für unser Partnerprogramm entscheiden sollten.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="flex gap-4">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0" />
              <div>
                <h3 className="text-xl font-bold mb-2">Großzügige Provisionen</h3>
                <p className="text-muted-foreground">
                  Verdienen Sie 10% Provision für jeden Kunden, den Sie empfehlen, für die gesamte Dauer seines
                  Abonnements.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0" />
              <div>
                <h3 className="text-xl font-bold mb-2">Lebenslange Cookies</h3>
                <p className="text-muted-foreground">
                  Unsere Cookies haben eine unbegrenzte Laufzeit, sodass Sie auch für spätere Käufe Provisionen
                  erhalten.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0" />
              <div>
                <h3 className="text-xl font-bold mb-2">Einfaches Tracking</h3>
                <p className="text-muted-foreground">
                  Verfolgen Sie Ihre Empfehlungen, Conversions und Provisionen in Echtzeit über Ihr Dashboard.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0" />
              <div>
                <h3 className="text-xl font-bold mb-2">Monatliche Auszahlungen</h3>
                <p className="text-muted-foreground">
                  Erhalten Sie Ihre Provisionen jeden Monat zuverlässig per Banküberweisung oder PayPal.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0" />
              <div>
                <h3 className="text-xl font-bold mb-2">Marketingmaterialien</h3>
                <p className="text-muted-foreground">
                  Zugang zu professionellen Bannern, E-Mail-Vorlagen und anderen Marketingmaterialien.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0" />
              <div>
                <h3 className="text-xl font-bold mb-2">Dedizierter Support</h3>
                <p className="text-muted-foreground">
                  Unser Affiliate-Team steht Ihnen bei Fragen oder Problemen zur Verfügung.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Join Program */}
      <section id="join" className="py-20">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Werden Sie Partner</h2>
            <p className="text-muted-foreground text-lg">
              Treten Sie unserem Partnerprogramm bei und beginnen Sie, Provisionen zu verdienen.
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <Tabs defaultValue={user ? "dashboard" : "join"}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="join">Beitreten</TabsTrigger>
                <TabsTrigger value="dashboard" disabled={!user}>
                  Partner-Dashboard
                </TabsTrigger>
              </TabsList>
              <TabsContent value="join" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Dem Partnerprogramm beitreten</CardTitle>
                    <CardDescription>
                      Füllen Sie das Formular aus, um dem Partnerprogramm beizutreten und Ihren Empfehlungscode zu
                      erhalten.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {user ? (
                      <div className="space-y-6">
                        <div className="space-y-2">
                          <Label>Nutzername</Label>
                          <Input value={user.email} disabled />
                        </div>
                        <Button onClick={handleJoinProgram} disabled={isLoading} className="w-full">
                          {isLoading ? "Verarbeitung..." : "Jetzt beitreten"}
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-6">
                        <p className="text-center">Sie müssen angemeldet sein, um dem Partnerprogramm beizutreten.</p>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                          <Button asChild>
                            <Link href="/login">Anmelden</Link>
                          </Button>
                          <Button asChild variant="outline">
                            <Link href="/signup">Registrieren</Link>
                          </Button>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="dashboard" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Partner-Dashboard</CardTitle>
                    <CardDescription>Verfolgen Sie Ihre Empfehlungen und Provisionen.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {referralCode ? (
                      <div className="space-y-6">
                        <div className="space-y-2">
                          <Label>Ihr Empfehlungscode</Label>
                          <div className="flex">
                            <Input value={referralCode} readOnly className="rounded-r-none" />
                            <Button variant="outline" className="rounded-l-none" onClick={copyReferralLink}>
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Teilen Sie diesen Code oder den vollständigen Link: https://afrocraft.com/signup?ref=
                            {referralCode}
                          </p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <Card>
                            <CardContent className="pt-6">
                              <div className="text-center">
                                <p className="text-muted-foreground text-sm">Empfehlungen</p>
                                <p className="text-3xl font-bold">{affiliateStats.referrals}</p>
                              </div>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="pt-6">
                              <div className="text-center">
                                <p className="text-muted-foreground text-sm">Ausstehende Provision</p>
                                <p className="text-3xl font-bold">€{affiliateStats.pendingCommission}</p>
                              </div>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardContent className="pt-6">
                              <div className="text-center">
                                <p className="text-muted-foreground text-sm">Gesamtverdienst</p>
                                <p className="text-3xl font-bold">€{affiliateStats.totalEarnings}</p>
                              </div>
                            </CardContent>
                          </Card>
                        </div>

                        <div className="text-center">
                          <Button asChild>
                            <Link href="/dashboard/affiliate">
                              Zum vollständigen Dashboard
                              <ArrowRight className="ml-2 h-4 w-4" />
                            </Link>
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center">
                        <p>Sie sind noch nicht Teil des Partnerprogramms.</p>
                        <Button onClick={handleJoinProgram} className="mt-4">
                          Jetzt beitreten
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Häufig gestellte Fragen</h2>
            <p className="text-muted-foreground text-lg">
              Antworten auf die häufigsten Fragen zu unserem Partnerprogramm.
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-4">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-2">Wer kann dem Partnerprogramm beitreten?</h3>
                <p className="text-muted-foreground">
                  Jeder kann unserem Partnerprogramm beitreten. Es ist ideal für Webdesigner, Marketingagenturen,
                  Blogger und alle, die mit Unternehmen arbeiten, die Webdesign-Dienstleistungen benötigen.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-2">Wie hoch ist die Provision?</h3>
                <p className="text-muted-foreground">
                  Sie erhalten 10% Provision für jeden Kunden, den Sie empfehlen, für die gesamte Dauer seines
                  Abonnements. Bei einem Jahresabonnement für €1.200 würden Sie €120 verdienen.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-2">Wann werden die Provisionen ausgezahlt?</h3>
                <p className="text-muted-foreground">
                  Provisionen werden monatlich ausgezahlt, vorausgesetzt, Ihr Guthaben übersteigt €50. Zahlungen
                  erfolgen per Banküberweisung oder PayPal.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-2">Wie lange sind die Cookies gültig?</h3>
                <p className="text-muted-foreground">
                  Unsere Cookies haben eine unbegrenzte Laufzeit. Wenn ein Benutzer über Ihren Link auf unsere Website
                  kommt und sich später anmeldet, erhalten Sie trotzdem die Provision.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-2">Kann ich meine eigenen Marketingmaterialien erstellen?</h3>
                <p className="text-muted-foreground">
                  Ja, Sie können Ihre eigenen Marketingmaterialien erstellen. Wir bieten jedoch auch professionelle
                  Banner, E-Mail-Vorlagen und andere Materialien, die Sie verwenden können.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-[#0f0a1e] text-white relative overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="container text-center max-w-3xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">Bereit, Partner zu werden?</h2>
          <p className="text-white/80 text-lg mb-8 animate-slide-up">
            Treten Sie unserem Partnerprogramm bei und beginnen Sie, Provisionen zu verdienen.
          </p>
          <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90 animate-slide-up">
            <a href="#join">Jetzt beitreten</a>
          </Button>
        </div>
      </section>
    </div>
  )
}
