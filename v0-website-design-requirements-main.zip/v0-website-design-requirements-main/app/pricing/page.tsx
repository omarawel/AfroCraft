import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, HelpCircle } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export default function PricingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-[#0f0a1e] py-20 md:py-32 overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="blob blob-2 animate-rotate" style={{ animationDirection: "reverse" }}></div>
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight text-white animate-fade-in">
              <span className="block">Transparente Preise</span>
              <span className="block">
                für <span className="text-primary">jeden Bedarf</span>
              </span>
            </h1>
            <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto animate-slide-up">
              Wählen Sie das Paket, das am besten zu Ihren Anforderungen und Ihrem Budget passt.
            </p>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 -mt-10 relative z-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="animate-scale relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary/40 to-primary"></div>
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl">Basic</CardTitle>
                <div className="mt-4 mb-2">
                  <span className="text-4xl font-bold">€600</span>
                  <span className="text-muted-foreground ml-2">einmalig</span>
                </div>
                <p className="text-sm text-muted-foreground">Ideal für kleine Unternehmen und Startups</p>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <PricingFeature feature="5-seitige responsive Website" />
                  <PricingFeature feature="Grundlegende SEO-Einrichtung" />
                  <PricingFeature feature="Kontaktformular" />
                  <PricingFeature feature="Mobil-responsives Design" />
                  <PricingFeature feature="3 Monate Support" />
                  <PricingFeature feature="Content-Management-System" available={false} />
                  <PricingFeature feature="E-Commerce-Funktionalität" available={false} />
                  <PricingFeature feature="Benutzerdefinierte Animationen" available={false} />
                </ul>
                <Button asChild className="w-full bg-primary hover:bg-primary/90">
                  <Link href="/contact">Jetzt starten</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="animate-scale relative overflow-hidden border-primary shadow-lg scale-105 z-10">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-purple-600"></div>
              <div className="absolute -top-4 left-0 right-0 flex justify-center">
                <div className="bg-primary text-white text-xs px-3 py-1 rounded-full">Beliebteste Wahl</div>
              </div>
              <CardHeader className="text-center pb-4 pt-6">
                <CardTitle className="text-2xl">Pro</CardTitle>
                <div className="mt-4 mb-2">
                  <span className="text-4xl font-bold">€1.100</span>
                  <span className="text-muted-foreground ml-2">einmalig</span>
                </div>
                <p className="text-sm text-muted-foreground">Perfekt für wachsende Unternehmen</p>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <PricingFeature feature="10-seitige responsive Website" />
                  <PricingFeature feature="Erweiterte SEO-Optimierung" />
                  <PricingFeature feature="Content-Management-System" />
                  <PricingFeature feature="Blog-Einrichtung" />
                  <PricingFeature feature="Social-Media-Integration" />
                  <PricingFeature feature="6 Monate Support" />
                  <PricingFeature feature="E-Commerce-Funktionalität" available={false} />
                  <PricingFeature feature="Benutzerdefinierte Animationen" available={false} />
                </ul>
                <Button asChild className="w-full bg-primary hover:bg-primary/90">
                  <Link href="/contact">Jetzt starten</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="animate-scale relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-purple-600"></div>
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl">Premium</CardTitle>
                <div className="mt-4 mb-2">
                  <span className="text-4xl font-bold">€2.000</span>
                  <span className="text-muted-foreground ml-2">einmalig</span>
                </div>
                <p className="text-sm text-muted-foreground">Für Unternehmen mit hohen Ansprüchen</p>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <PricingFeature feature="Maßgeschneiderte Website (unbegrenzte Seiten)" />
                  <PricingFeature feature="E-Commerce-Funktionalität" />
                  <PricingFeature feature="Erweiterte SEO-Strategie" />
                  <PricingFeature feature="Benutzerdefinierte Animationen und Interaktionen" />
                  <PricingFeature feature="Benutzerkontensystem" />
                  <PricingFeature feature="1 Jahr prioritärer Support" />
                  <PricingFeature feature="Leistungsanalyse und Berichte" />
                  <PricingFeature feature="Mehrsprachige Website-Unterstützung" />
                </ul>
                <Button asChild className="w-full bg-primary hover:bg-primary/90">
                  <Link href="/contact">Jetzt starten</Link>
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <p className="text-muted-foreground mb-4">
              Benötigen Sie eine individuelle Lösung? Wir erstellen gerne ein maßgeschneidertes Angebot für Sie.
            </p>
            <Button asChild variant="outline">
              <Link href="/contact?demo=true">Individuelles Angebot oder Demo anfragen</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Company Info Section */}
      <section className="py-16 bg-gray-50">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Über WebCraft Studio</h2>
              <p className="text-lg text-muted-foreground">
                Ein junges, innovatives Startup aus Düsseldorf mit Leidenschaft für modernes Webdesign
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div className="p-6 rounded-lg bg-white shadow-sm">
                <h3 className="text-xl font-semibold mb-2">Standort</h3>
                <p>Königsallee 92, 40212 Düsseldorf, Deutschland</p>
              </div>

              <div className="p-6 rounded-lg bg-white shadow-sm">
                <h3 className="text-xl font-semibold mb-2">Gegründet</h3>
                <p>2024 - Ein junges Startup mit frischen Ideen</p>
              </div>

              <div className="p-6 rounded-lg bg-white shadow-sm">
                <h3 className="text-xl font-semibold mb-2">Spezialisierung</h3>
                <p>Responsive Webdesign, E-Commerce und digitale Transformation</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Häufig gestellte Fragen</h2>
            <p className="text-muted-foreground text-lg">
              Hier finden Sie Antworten auf die häufigsten Fragen zu unseren Preisen und Leistungen.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Was ist in den Preisen enthalten?</h3>
              <p className="text-muted-foreground">
                Unsere Preise beinhalten Design, Entwicklung, Responsive-Optimierung, grundlegende SEO-Einrichtung und
                Support für den angegebenen Zeitraum. Hosting und Domain sind separat erhältlich.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Gibt es versteckte Kosten?</h3>
              <p className="text-muted-foreground">
                Nein, wir sind transparent mit unseren Preisen. Alle Kosten werden im Voraus besprochen und in unserem
                Angebot detailliert aufgeführt.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Wie lange dauert die Erstellung meiner Website?</h3>
              <p className="text-muted-foreground">
                Die Zeitspanne variiert je nach Komplexität des Projekts. Basic-Websites können in 2-4 Wochen fertig
                sein, während Premium-Projekte 8-12 Wochen dauern können.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Kann ich mein Paket später upgraden?</h3>
              <p className="text-muted-foreground">
                Ja, Sie können jederzeit auf ein höheres Paket upgraden oder zusätzliche Funktionen hinzufügen. Wir
                besprechen gerne die Optionen mit Ihnen.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Bieten Sie Hosting-Dienste an?</h3>
              <p className="text-muted-foreground">
                Ja, wir bieten Hosting-Pakete ab €15/Monat an, die regelmäßige Backups, Sicherheitsupdates und
                technischen Support umfassen.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-semibold">Kann ich eine Demo oder Präsentation erhalten?</h3>
              <p className="text-muted-foreground">
                Selbstverständlich! Wir bieten kostenlose Beratungsgespräche und Demo-Präsentationen an, um Ihnen zu
                zeigen, wie wir Ihre Vision umsetzen können. Kontaktieren Sie uns einfach für einen Termin.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#0f0a1e] text-white relative overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="container text-center max-w-3xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">Bereit, Ihre Website zu erstellen?</h2>
          <p className="text-white/80 text-lg mb-8 animate-slide-up">
            Kontaktieren Sie uns noch heute für ein unverbindliches Gespräch über Ihr Projekt.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
            <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
              <Link href="/contact">Kontakt aufnehmen</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
              <Link href="/portfolio">Unsere Arbeit ansehen</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

function PricingFeature({ feature, available = true }: { feature: string; available?: boolean }) {
  return (
    <TooltipProvider>
      <li className="flex items-start">
        <Check className={`h-5 w-5 mr-2 mt-0.5 ${available ? "text-primary" : "text-gray-300"}`} />
        <span className={available ? "" : "text-gray-400"}>{feature}</span>
        {!available && (
          <Tooltip>
            <TooltipTrigger asChild>
              <HelpCircle className="h-4 w-4 ml-1 text-gray-400" />
            </TooltipTrigger>
            <TooltipContent>
              <p>In höheren Paketen verfügbar</p>
            </TooltipContent>
          </Tooltip>
        )}
      </li>
    </TooltipProvider>
  )
}
