"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  PieChart,
  Users,
  FileText,
  MessageSquare,
  Calendar,
  Settings,
  Plus,
  Search,
  Download,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function AdminDashboardPage() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div className="container py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage your clients, projects, and team members.</p>
        </div>
        <Button asChild className="bg-primary hover:bg-primary/90">
          <Link href="/admin/new-project">
            <Plus className="h-4 w-4 mr-2" />
            New Project
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">42</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">↑ 12%</span> from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Projects</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">18</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">↑ 8%</span> from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">€24,500</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">↑ 15%</span> from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Support Tickets</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">7</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-red-500">↑ 3</span> unresolved
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Revenue Overview</CardTitle>
            <CardDescription>Monthly revenue for the current year</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80 flex items-center justify-center bg-muted/20 rounded-md">
              <BarChart className="h-16 w-16 text-muted-foreground" />
              <span className="ml-4 text-muted-foreground">Revenue chart visualization would appear here</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Project Distribution</CardTitle>
            <CardDescription>Projects by category</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <div className="flex items-center justify-center h-48 bg-muted/20 rounded-md mb-4">
                <PieChart className="h-16 w-16 text-muted-foreground" />
              </div>
              <div className="space-y-2">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-primary mr-2"></div>
                  <span className="text-sm">Business Websites (45%)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
                  <span className="text-sm">E-Commerce (30%)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                  <span className="text-sm">Portfolios (15%)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                  <span className="text-sm">Blogs (10%)</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-8">
        <Card>
          <CardHeader>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <CardTitle>Client Management</CardTitle>
                <CardDescription>View and manage all your clients</CardDescription>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search clients..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Select defaultValue="all">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Clients</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="new">New</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <div className="relative w-full overflow-auto">
                <table className="w-full caption-bottom text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="h-12 px-4 text-left align-middle font-medium">Client</th>
                      <th className="h-12 px-4 text-left align-middle font-medium">Projects</th>
                      <th className="h-12 px-4 text-left align-middle font-medium">Status</th>
                      <th className="h-12 px-4 text-left align-middle font-medium">Last Activity</th>
                      <th className="h-12 px-4 text-right align-middle font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {clients.map((client, index) => (
                      <tr key={index} className="border-b">
                        <td className="p-4 align-middle">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full overflow-hidden bg-muted">
                              <Image
                                src={client.avatar || "/placeholder.svg?height=40&width=40"}
                                alt={client.name}
                                width={40}
                                height={40}
                                className="object-cover"
                              />
                            </div>
                            <div>
                              <div className="font-medium">{client.name}</div>
                              <div className="text-xs text-muted-foreground">{client.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 align-middle">{client.projects}</td>
                        <td className="p-4 align-middle">
                          <div
                            className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                              client.status === "Active"
                                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                : client.status === "Inactive"
                                  ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
                                  : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                            }`}
                          >
                            {client.status}
                          </div>
                        </td>
                        <td className="p-4 align-middle">{client.lastActivity}</td>
                        <td className="p-4 align-middle text-right">
                          <Button variant="ghost" size="sm" asChild>
                            <Link href={`/admin/clients/${client.id}`}>View</Link>
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="flex items-center justify-end space-x-2 py-4">
              <Button variant="outline" size="sm">
                Previous
              </Button>
              <Button variant="outline" size="sm">
                Next
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activities</CardTitle>
            <CardDescription>Latest actions and updates</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {activities.map((activity, index) => (
                <div key={index} className="flex">
                  <div className="relative mr-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      {activity.icon}
                    </div>
                    {index !== activities.length - 1 && (
                      <div className="absolute bottom-0 left-1/2 top-10 w-px -translate-x-1/2 bg-border"></div>
                    )}
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <p className="text-sm font-medium">{activity.title}</p>
                    <p className="text-sm text-muted-foreground">{activity.description}</p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

const clients = [
  {
    id: "1",
    name: "Acme Corporation",
    email: "contact@acme.com",
    projects: 3,
    status: "Active",
    lastActivity: "Today",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "2",
    name: "Globex Industries",
    email: "info@globex.com",
    projects: 2,
    status: "Active",
    lastActivity: "Yesterday",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "3",
    name: "Stark Enterprises",
    email: "hello@stark.com",
    projects: 1,
    status: "New",
    lastActivity: "2 days ago",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "4",
    name: "Wayne Industries",
    email: "contact@wayne.com",
    projects: 4,
    status: "Active",
    lastActivity: "3 days ago",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "5",
    name: "Umbrella Corp",
    email: "info@umbrella.com",
    projects: 0,
    status: "Inactive",
    lastActivity: "1 week ago",
    avatar: "/placeholder.svg?height=40&width=40",
  },
]

const activities = [
  {
    icon: <FileText className="h-5 w-5 text-primary" />,
    title: "New project created",
    description: "E-commerce website for Acme Corporation",
    time: "1 hour ago",
  },
  {
    icon: <Users className="h-5 w-5 text-primary" />,
    title: "New client registered",
    description: "Stark Enterprises signed up for a Pro plan",
    time: "3 hours ago",
  },
  {
    icon: <MessageSquare className="h-5 w-5 text-primary" />,
    title: "New support ticket",
    description: "Globex Industries reported an issue with their contact form",
    time: "5 hours ago",
  },
  {
    icon: <Calendar className="h-5 w-5 text-primary" />,
    title: "Meeting scheduled",
    description: "Project kickoff meeting with Wayne Industries",
    time: "Yesterday",
  },
  {
    icon: <Settings className="h-5 w-5 text-primary" />,
    title: "System update completed",
    description: "Platform updated to version 2.4.0",
    time: "2 days ago",
  },
]
