"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  FileText,
  Users,
  ShoppingCart,
  MessageSquare,
  Settings,
  LogOut,
  ImageIcon,
  PanelLeft,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { useState } from "react"

export function AdminSidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)

  const toggleSidebar = () => {
    setCollapsed(!collapsed)
  }

  return (
    <div
      className={cn(
        "bg-slate-900 text-white h-screen sticky top-0 transition-all duration-300",
        collapsed ? "w-16" : "w-64",
      )}
    >
      <div className="flex items-center justify-between p-4 border-b border-slate-700">
        <h2 className={cn("font-bold text-xl", collapsed && "hidden")}>WebCraft Admin</h2>
        <Button variant="ghost" size="icon" onClick={toggleSidebar} className="text-white hover:bg-slate-800">
          <PanelLeft className="h-5 w-5" />
        </Button>
      </div>

      <div className="p-4">
        <nav className="space-y-2">
          <NavItem
            href="/admin/dashboard"
            icon={<LayoutDashboard className="h-5 w-5" />}
            label="Dashboard"
            active={pathname === "/admin/dashboard"}
            collapsed={collapsed}
          />
          <NavItem
            href="/admin/dashboard/blog"
            icon={<FileText className="h-5 w-5" />}
            label="Blog"
            active={pathname.includes("/admin/dashboard/blog")}
            collapsed={collapsed}
          />
          <NavItem
            href="/admin/dashboard/portfolio"
            icon={<ImageIcon className="h-5 w-5" />}
            label="Portfolio"
            active={pathname.includes("/admin/dashboard/portfolio")}
            collapsed={collapsed}
          />
          <NavItem
            href="/admin/dashboard/clients"
            icon={<Users className="h-5 w-5" />}
            label="Kunden"
            active={pathname.includes("/admin/dashboard/clients")}
            collapsed={collapsed}
          />
          <NavItem
            href="/admin/dashboard/products"
            icon={<ShoppingCart className="h-5 w-5" />}
            label="Produkte"
            active={pathname.includes("/admin/dashboard/products")}
            collapsed={collapsed}
          />
          <NavItem
            href="/admin/dashboard/contacts"
            icon={<MessageSquare className="h-5 w-5" />}
            label="Kontakte"
            active={pathname.includes("/admin/dashboard/contacts")}
            collapsed={collapsed}
          />
        </nav>
      </div>

      <div className="absolute bottom-0 w-full border-t border-slate-700 p-4">
        <div className="space-y-2">
          <NavItem
            href="/admin/dashboard/settings"
            icon={<Settings className="h-5 w-5" />}
            label="Einstellungen"
            active={pathname.includes("/admin/dashboard/settings")}
            collapsed={collapsed}
          />
          <NavItem
            href="/logout"
            icon={<LogOut className="h-5 w-5" />}
            label="Abmelden"
            active={false}
            collapsed={collapsed}
          />
        </div>
      </div>
    </div>
  )
}

interface NavItemProps {
  href: string
  icon: React.ReactNode
  label: string
  active: boolean
  collapsed: boolean
}

function NavItem({ href, icon, label, active, collapsed }: NavItemProps) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center space-x-2 rounded-md px-3 py-2 hover:bg-slate-800 transition-colors",
        active && "bg-slate-800 text-primary",
      )}
    >
      <span>{icon}</span>
      {!collapsed && <span>{label}</span>}
    </Link>
  )
}
