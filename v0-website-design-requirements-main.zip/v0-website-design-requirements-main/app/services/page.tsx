import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Check } from "lucide-react"

export default function ServicesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-[#0f0a1e] py-16 md:py-24 relative overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="container text-center max-w-3xl mx-auto animate-fade-in relative z-10">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Unsere Dienstleistungen</h1>
          <p className="text-lg text-white/80 mb-8">
            Wir bieten umfassende Webdesign- und Entwicklungsdienstleistungen, um Ihrem Unternehmen online zum Erfolg zu
            verhelfen.
          </p>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 animate-slide-in-left">
              <h2 className="text-3xl font-bold">Maßgeschneidertes Webdesign & Entwicklung</h2>
              <p className="text-muted-foreground">
                Wir erstellen schöne, funktionale Websites, die auf Ihre Marke und Geschäftsziele zugeschnitten sind.
                Unsere maßgeschneiderten Websites sind darauf ausgelegt, Besucher anzuziehen, sie mit überzeugenden
                Inhalten zu fesseln und in Kunden zu verwandeln.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Responsives Design, das auf allen Geräten funktioniert</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Benutzerfreundliche Navigation und intuitive Benutzeroberflächen</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>SEO-freundliche Struktur und schnelle Ladezeiten</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                  <span>Content-Management-Systeme für einfache Updates</span>
                </li>
              </ul>
            </div>
            <div className="bg-gray-50 rounded-lg p-8 animate-slide-in-right">
              <h3 className="text-xl font-bold mb-4">Unser Entwicklungsprozess</h3>
              <ol className="space-y-6">
                <li className="flex">
                  <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center mr-4">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold">Entdeckung & Planung</h4>
                    <p className="text-muted-foreground">
                      Wir lernen Ihr Unternehmen, Ihre Ziele und Ihre Zielgruppe kennen, um einen strategischen Plan zu
                      erstellen.
                    </p>
                  </div>
                </li>
                <li className="flex">
                  <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center mr-4">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold">Design & Prototyping</h4>
                    <p className="text-muted-foreground">
                      Wir erstellen Wireframes und visuelle Designs zur Genehmigung, bevor die Entwicklung beginnt.
                    </p>
                  </div>
                </li>
                <li className="flex">
                  <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center mr-4">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold">Entwicklung</h4>
                    <p className="text-muted-foreground">
                      Wir bauen Ihre Website mit modernen Technologien und Best Practices.
                    </p>
                  </div>
                </li>
                <li className="flex">
                  <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center mr-4">
                    4
                  </div>
                  <div>
                    <h4 className="font-semibold">Testen & Launch</h4>
                    <p className="text-muted-foreground">
                      Wir testen Ihre Website gründlich und stellen sie in Ihrer Hosting-Umgebung bereit.
                    </p>
                  </div>
                </li>
              </ol>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 bg-gray-50">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16 animate-slide-up">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Unsere Pakete</h2>
            <p className="text-muted-foreground text-lg">
              Wählen Sie das Paket, das am besten zu Ihren Geschäftsanforderungen und Ihrem Budget passt.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="animate-scale">
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl">Basic</CardTitle>
                <div className="mt-4 mb-2">
                  <span className="text-4xl font-bold">€600</span>
                  <span className="text-muted-foreground ml-2">einmalig</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>5-seitige responsive Website</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>Grundlegende SEO-Einrichtung</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>Kontaktformular</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>Mobil-responsives Design</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>3 Monate Support</span>
                  </li>
                </ul>
                <Button asChild className="w-full bg-primary hover:bg-primary/90 text-white">
                  <Link href="/contact">Jetzt starten</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-primary animate-scale relative" style={{ animationDelay: "0.1s" }}>
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-primary text-white px-4 py-1 rounded-full text-sm font-medium">
                Beliebteste Wahl
              </div>
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl">Pro</CardTitle>
                <div className="mt-4 mb-2">
                  <span className="text-4xl font-bold">€1.100</span>
                  <span className="text-muted-foreground ml-2">einmalig</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>10-seitige responsive Website</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>Erweiterte SEO-Optimierung</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>Content-Management-System</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>Blog-Einrichtung</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>Social-Media-Integration</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>6 Monate Support</span>
                  </li>
                </ul>
                <Button asChild className="w-full bg-primary hover:bg-primary/90 text-white">
                  <Link href="/contact">Jetzt starten</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="animate-scale" style={{ animationDelay: "0.2s" }}>
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl">Premium</CardTitle>
                <div className="mt-4 mb-2">
                  <span className="text-4xl font-bold">€2.000</span>
                  <span className="text-muted-foreground ml-2">einmalig</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>Maßgeschneiderte Website (unbegrenzte Seiten)</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>E-Commerce-Funktionalität</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>Erweiterte SEO-Strategie</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>Benutzerdefinierte Animationen und Interaktionen</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>Benutzerkontensystem</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <span>1 Jahr prioritärer Support</span>
                  </li>
                </ul>
                <Button asChild className="w-full bg-primary hover:bg-primary/90 text-white">
                  <Link href="/contact">Jetzt starten</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16 animate-slide-up">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Häufig gestellte Fragen</h2>
            <p className="text-muted-foreground text-lg">
              Finden Sie Antworten auf häufig gestellte Fragen zu unseren Webdesign- und Entwicklungsdienstleistungen.
            </p>
          </div>

          <div className="max-w-3xl mx-auto animate-slide-up">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>Wie lange dauert es, eine Website zu erstellen?</AccordionTrigger>
                <AccordionContent>
                  Der Zeitrahmen für die Website-Entwicklung variiert je nach Komplexität des Projekts. Eine einfache
                  Website dauert in der Regel 4-6 Wochen, während komplexere Projekte mit benutzerdefinierten Funktionen
                  8-12 Wochen oder länger dauern können. Wir stellen Ihnen während unserer ersten Beratung einen
                  detaillierten Zeitplan zur Verfügung.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger>Bieten Sie Website-Hosting an?</AccordionTrigger>
                <AccordionContent>
                  Ja, wir bieten Website-Hosting-Dienste an, um sicherzustellen, dass Ihre Website schnell, sicher und
                  zuverlässig bleibt. Unsere Hosting-Pakete umfassen regelmäßige Backups, Sicherheitsüberwachung und
                  technischen Support. Wir können auch mit Ihrem bestehenden Hosting-Anbieter zusammenarbeiten, wenn Sie
                  dies bevorzugen.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger>
                  Kann ich die Website selbst aktualisieren, nachdem sie erstellt wurde?
                </AccordionTrigger>
                <AccordionContent>
                  Wir erstellen die meisten unserer Websites auf benutzerfreundlichen Content-Management-Systemen (CMS),
                  die es Ihnen ermöglichen, Inhalte einfach zu aktualisieren, neue Seiten hinzuzufügen und grundlegende
                  Änderungen ohne technisches Wissen vorzunehmen. Wir bieten auch Schulungen an, um sicherzustellen,
                  dass Sie sich mit der Verwaltung Ihrer Website wohlfühlen.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger>Wie ist Ihre Zahlungsstruktur?</AccordionTrigger>
                <AccordionContent>
                  Wir verlangen in der Regel eine Anzahlung von 50%, um mit der Arbeit zu beginnen, wobei der Restbetrag
                  bei Projektabschluss fällig wird. Bei größeren Projekten können wir einen meilensteinbasierten
                  Zahlungsplan erstellen. Wir akzeptieren Zahlungen per Kreditkarte, Banküberweisung oder PayPal.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-5">
                <AccordionTrigger>Bieten Sie laufende Wartungsdienste an?</AccordionTrigger>
                <AccordionContent>
                  Ja, wir bieten Website-Wartungspakete an, um Ihre Website sicher, aktuell und optimal funktionierend
                  zu halten. Unsere Wartungsdienste umfassen regelmäßige Updates, Sicherheitsüberwachung,
                  Leistungsoptimierung und technischen Support. Wir empfehlen eine kontinuierliche Wartung für alle
                  Websites, um sicherzustellen, dass sie weiterhin ordnungsgemäß funktionieren.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-6">
                <AccordionTrigger>Was ist, wenn ich nach dem Start der Website Änderungen benötige?</AccordionTrigger>
                <AccordionContent>
                  Wir bieten eine 30-tägige Garantiezeit nach dem Start, in der wir alle Probleme beheben oder kleinere
                  Anpassungen kostenlos vornehmen. Darüber hinaus bieten wir Stundensätze für kleine Änderungen oder
                  Wartungspakete für laufenden Support an. Wir sind immer da, um Ihnen zu helfen, Ihre Website
                  weiterzuentwickeln, während Ihr Unternehmen wächst.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#0f0a1e] text-white relative overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="container text-center max-w-3xl mx-auto animate-fade-in relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Bereit loszulegen?</h2>
          <p className="text-white/80 text-lg mb-8">
            Kontaktieren Sie uns noch heute, um Ihr Projekt zu besprechen und eine kostenlose Beratung zu erhalten.
          </p>
          <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
            <Link href="/contact">Kontaktieren Sie uns</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
