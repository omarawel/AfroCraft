"use client"

import type React from "react"

import { useState } from "react"
import { useToast } from "@/components/ui/use-toast"
import { getBrowserClient } from "@/lib/supabase"

interface FileUploadProps {
  projectId: string
  onUploadComplete?: (fileUrl: string, fileName: string) => void
  allowedTypes?: string[]
  maxSize?: number // in MB
}

export function FileUpload({
  projectId,
  onUploadComplete,
  allowedTypes = ["image/*", "application/pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx"],
  maxSize = 10, // 10MB default
}: FileUploadProps) {
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const { toast } = useToast()
  const supabase = getBrowserClient()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) {
      setFile(null)
      return
    }

    const selectedFile = e.target.files[0]

    // Check file size
    if (selectedFile.size > maxSize * 1024 * 1024) {
      toast({
        title: "Datei zu groß",
        description: `Die maximale Dateigröße beträgt ${maxSize}MB.`,
        variant: "destructive",
      })
      return
    }

    // Check file type
    const fileType = selectedFile.type
    const fileExtension = `.${selectedFile.name.split(".").pop()}`
    
    const isAllowedType = allowedTypes.some(type => {
      if (type.includes("*")) {
        return fileType.startsWith(type.split("*")[0])
      }
      return type === fileType || type === fileExtension
    })

    if (!isAllowedType) {
      toast({
        title: "Nicht unterstützter Dateityp",
        description: \"Bitte wählen Sie eine Datei mit einem unt
