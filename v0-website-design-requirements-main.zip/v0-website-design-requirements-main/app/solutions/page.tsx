import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle2, ArrowRight } from "lucide-react"

export default function SolutionsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-[#0f0a1e] py-20 md:py-32 overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="blob blob-2 animate-rotate" style={{ animationDirection: "reverse" }}></div>
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight text-white animate-fade-in">
              <span className="block">Maßgeschneiderte Lösungen</span>
              <span className="block">
                für <span className="text-primary">Ihren Erfolg</span>
              </span>
            </h1>
            <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto animate-slide-up">
              Wir bieten spezialisierte Lösungen für verschiedene Branchen und Anforderungen, um Ihren Online-Erfolg zu
              maximieren.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
              <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
                <Link href="/contact">Beratungsgespräch vereinbaren</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
                <Link href="/portfolio">Referenzen ansehen</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Solutions Tabs */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Unsere Lösungen im Überblick</h2>
            <p className="text-muted-foreground text-lg">
              Entdecken Sie unsere spezialisierten Lösungen für verschiedene Branchen und Anforderungen.
            </p>
          </div>

          <Tabs defaultValue="business" className="w-full max-w-4xl mx-auto">
            <TabsList className="grid w-full grid-cols-4 mb-12">
              <TabsTrigger value="business">Business</TabsTrigger>
              <TabsTrigger value="ecommerce">E-Commerce</TabsTrigger>
              <TabsTrigger value="creative">Kreative</TabsTrigger>
              <TabsTrigger value="nonprofit">Non-Profit</TabsTrigger>
            </TabsList>

            <TabsContent value="business" className="animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                  <h3 className="text-2xl font-bold">Geschäftslösungen</h3>
                  <p className="text-muted-foreground">
                    Professionelle Websites für Unternehmen jeder Größe, die Ihre Marke stärken und Leads generieren.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Professionelles Unternehmensdesign</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Lead-Generierungsformulare</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Team- und Dienstleistungspräsentation</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Integrierte Buchungssysteme</span>
                    </li>
                  </ul>
                  <Button asChild className="bg-primary hover:bg-primary/90">
                    <Link href="/contact">Beratung anfragen</Link>
                  </Button>
                </div>
                <div className="rounded-lg overflow-hidden shadow-xl">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    alt="Business Solution"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="ecommerce" className="animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className="rounded-lg overflow-hidden shadow-xl order-2 md:order-1">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    alt="E-Commerce Solution"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
                <div className="space-y-6 order-1 md:order-2">
                  <h3 className="text-2xl font-bold">E-Commerce-Lösungen</h3>
                  <p className="text-muted-foreground">
                    Leistungsstarke Online-Shops mit allem, was Sie für den Verkauf Ihrer Produkte benötigen.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Benutzerfreundlicher Produktkatalog</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Sichere Zahlungsabwicklung</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Inventar- und Bestellverwaltung</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Kundenkonten und Treueprogramme</span>
                    </li>
                  </ul>
                  <Button asChild className="bg-primary hover:bg-primary/90">
                    <Link href="/contact">Beratung anfragen</Link>
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="creative" className="animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                  <h3 className="text-2xl font-bold">Lösungen für Kreative</h3>
                  <p className="text-muted-foreground">
                    Beeindruckende Portfolios und Websites für Künstler, Designer, Fotografen und Kreativschaffende.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Visuell ansprechende Portfolios</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Optimierte Bildergalerien</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Projektpräsentationen</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Kontakt- und Buchungsformulare</span>
                    </li>
                  </ul>
                  <Button asChild className="bg-primary hover:bg-primary/90">
                    <Link href="/contact">Beratung anfragen</Link>
                  </Button>
                </div>
                <div className="rounded-lg overflow-hidden shadow-xl">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    alt="Creative Solution"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="nonprofit" className="animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className="rounded-lg overflow-hidden shadow-xl order-2 md:order-1">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    alt="Non-Profit Solution"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
                <div className="space-y-6 order-1 md:order-2">
                  <h3 className="text-2xl font-bold">Non-Profit-Lösungen</h3>
                  <p className="text-muted-foreground">
                    Spezialisierte Websites für gemeinnützige Organisationen, die Ihre Mission unterstützen.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Spendenformulare und -verwaltung</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Veranstaltungskalender</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Freiwilligenmanagement</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                      <span>Erfolgsgeschichten und Wirkungsberichte</span>
                    </li>
                  </ul>
                  <Button asChild className="bg-primary hover:bg-primary/90">
                    <Link href="/contact">Beratung anfragen</Link>
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Case Studies */}
      <section className="py-20 bg-gray-50">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Erfolgsgeschichten</h2>
            <p className="text-muted-foreground text-lg">
              Entdecken Sie, wie unsere Lösungen Unternehmen und Organisationen zum Erfolg verholfen haben.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {caseStudies.map((study, index) => (
              <Card
                key={index}
                className="overflow-hidden hover:shadow-lg transition-all animate-scale"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={study.image || "/placeholder.svg?height=200&width=400"}
                    alt={study.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-bold">{study.title}</h3>
                    <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">{study.category}</span>
                  </div>
                  <p className="text-muted-foreground mb-4">{study.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">{study.client}</span>
                    <Link
                      href={`/case-studies/${study.slug}`}
                      className="text-primary font-medium flex items-center hover:underline"
                    >
                      Mehr erfahren <ArrowRight className="h-4 w-4 ml-1" />
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#0f0a1e] text-white relative overflow-hidden">
        <div className="blob blob-1 animate-rotate"></div>
        <div className="container text-center max-w-3xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">
            Bereit für Ihre maßgeschneiderte Lösung?
          </h2>
          <p className="text-white/80 text-lg mb-8 animate-slide-up">
            Kontaktieren Sie uns für ein unverbindliches Beratungsgespräch und erfahren Sie, wie wir Ihnen helfen
            können.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
            <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
              <Link href="/contact">Kontakt aufnehmen</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
              <Link href="/pricing">Preise ansehen</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

// Sample case studies data
const caseStudies = [
  {
    title: "Digitale Transformation",
    category: "Business",
    image: "/placeholder.svg?height=200&width=400",
    description:
      "Wie wir einem traditionellen Unternehmen geholfen haben, seine Online-Präsenz zu modernisieren und die Kundengewinnung zu steigern.",
    client: "Schmidt & Partner GmbH",
    slug: "schmidt-partner",
  },
  {
    title: "E-Commerce-Erfolg",
    category: "E-Commerce",
    image: "/placeholder.svg?height=200&width=400",
    description:
      "Die Entwicklung eines erfolgreichen Online-Shops, der den Umsatz um 150% steigerte und die Kundenzufriedenheit verbesserte.",
    client: "ModaStyle Boutique",
    slug: "modastyle-boutique",
  },
  {
    title: "Kreatives Portfolio",
    category: "Kreative",
    image: "/placeholder.svg?height=200&width=400",
    description:
      "Die Erstellung eines beeindruckenden Portfolios für einen Fotografen, das zu zahlreichen neuen Aufträgen und internationaler Anerkennung führte.",
    client: "Thomas Müller Fotografie",
    slug: "thomas-mueller-fotografie",
  },
]
