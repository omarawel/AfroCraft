import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Instagram, Linkedin, Twitter, InstagramIcon as TiktokIcon } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-muted/40 border-t dark:bg-gray-900">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center space-x-2">
              <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-600">
                AfroCraft
              </span>
            </Link>
            <p className="mt-4 text-sm text-muted-foreground">
              Wir sind ein innovatives Startup aus Düsseldorf, das maßgeschneiderte Webdesign- und Entwicklungslösungen
              anbietet.
            </p>
            <div className="flex mt-4 space-x-4">
              <Button variant="ghost" size="icon" asChild>
                <Link href="https://instagram.com/afrocraft" target="_blank" rel="noopener noreferrer">
                  <Instagram className="h-5 w-5" />
                  <span className="sr-only">Instagram</span>
                </Link>
              </Button>
              <Button variant="ghost" size="icon" asChild>
                <Link href="https://tiktok.com/@afrocraft" target="_blank" rel="noopener noreferrer">
                  <TiktokIcon className="h-5 w-5" />
                  <span className="sr-only">TikTok</span>
                </Link>
              </Button>
              <Button variant="ghost" size="icon" asChild>
                <Link href="https://linkedin.com/company/afrocraft" target="_blank" rel="noopener noreferrer">
                  <Linkedin className="h-5 w-5" />
                  <span className="sr-only">LinkedIn</span>
                </Link>
              </Button>
              <Button variant="ghost" size="icon" asChild>
                <Link href="https://x.com/afrocraft" target="_blank" rel="noopener noreferrer">
                  <Twitter className="h-5 w-5" />
                  <span className="sr-only">X (Twitter)</span>
                </Link>
              </Button>
            </div>
          </div>
          <div>
            <h3 className="text-sm font-semibold mb-4">Produkte</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/product" className="text-muted-foreground hover:text-primary">
                  Funktionen
                </Link>
              </li>
              <li>
                <Link href="/templates" className="text-muted-foreground hover:text-primary">
                  Templates
                </Link>
              </li>
              <li>
                <Link href="/solutions" className="text-muted-foreground hover:text-primary">
                  Lösungen
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="text-muted-foreground hover:text-primary">
                  Preise
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold mb-4">Unternehmen</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-primary">
                  Über uns
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-muted-foreground hover:text-primary">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/careers" className="text-muted-foreground hover:text-primary">
                  Karriere
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-primary">
                  Kontakt
                </Link>
              </li>
              <li>
                <Link href="/affiliate" className="text-muted-foreground hover:text-primary">
                  Partnerprogramm
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold mb-4">Newsletter</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Abonnieren Sie unseren Newsletter für die neuesten Updates und Angebote.
            </p>
            <div className="flex space-x-2">
              <Input type="email" placeholder="Ihre E-Mail-Adresse" className="max-w-[220px]" />
              <Button>Abonnieren</Button>
            </div>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-sm text-muted-foreground">
              &copy; {new Date().getFullYear()} AfroCraft. Alle Rechte vorbehalten.
            </div>
            <div className="flex flex-wrap gap-4 mt-4 md:mt-0 text-sm">
              <Link href="/terms" className="text-muted-foreground hover:text-primary">
                Nutzungsbedingungen
              </Link>
              <Link href="/privacy" className="text-muted-foreground hover:text-primary">
                Datenschutz
              </Link>
              <Link href="/imprint" className="text-muted-foreground hover:text-primary">
                Impressum
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
